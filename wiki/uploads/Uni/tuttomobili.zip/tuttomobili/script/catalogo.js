	onload = function runTransform(){
			if(document.implementation && document.implementation.createDocument){
				// Mozilla
		
				var xsltProcessor = new XSLTProcessor();
				
				// load the xslt file
				var myXMLHTTPRequest = new XMLHttpRequest();
				myXMLHTTPRequest.open('GET', 'catalogo.xsl', false);
				myXMLHTTPRequest.send(null);
				
				// get the XML document
				xslStylesheet = myXMLHTTPRequest.responseXML;
				xsltProcessor.importStylesheet(xslStylesheet);
				
				// load the xml file
				myXMLHTTPRequest = new XMLHttpRequest();
				myXMLHTTPRequest.open('GET', 'catalogo.xml', false);
				myXMLHTTPRequest.send(null);
				
				var xmlSource = myXMLHTTPRequest.responseXML;
				
				//transform
				 var resultDocument = xsltProcessor.transformToFragment(xmlSource, document);
				document.getElementById("content").appendChild(resultDocument);
				
			}else if(window.ActiveXObject){
				// IE
				
				// Load XML
				xml = new ActiveXObject("MSXML2.DOMDocument");
				xml.async = false
				xml.load('catalogo.xml')
				
				// Load XSL
				xsl = new ActiveXObject("MSXML2.DOMDocument");
				xsl.async = false
				xsl.load('catalogo.xsl')
				
			
				// Transform
				document.getElementById("content").innerHTML=xml.transformNode(xsl);
			}else{
				// Browser unknown
				alert("Browser unknown");
			}
		
		}