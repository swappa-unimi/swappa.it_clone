/**
 * Progetto di Laboratorio di Programmazione ad Oggetti: classe che consente la gestione dei dati anagrafici dei clienti
 * @author Mattia Cavenaghi, matricola: 736856
 */

import java.sql.*;

class AnagraficaClienti {
    ConnessioneDB miaConnessioneDB = new ConnessioneDB();
    Statement st = null;
    ResultSet rs = null;
    String [][] dati;

    /**
     * Operazione di registrazione dei dati di un nuovo cliente
     * @param idCliente Identificativo del nuovo cliente da registrare
     * @param nomeCliente Nome del nuovo cliente da registrare
     * @param cognomeCliente Cognome del nuovo cliente da registrare
     * @param indirizzoCliente Indirizzo del nuovo cliente da registrare
     */
    public void InserimentoDati (String idCliente, String nomeCliente, String cognomeCliente, String indirizzoCliente) {
        try {
            st = miaConnessioneDB.ConnessioneDB().createStatement();
            st.executeUpdate("INSERT INTO clienti VALUES ('" + idCliente + "', '" + nomeCliente + "', '" + cognomeCliente + "', '" + indirizzoCliente + "')");

            st.close();
            rs.close();
        }
        catch (Exception eccezione) {
            JavaAir.campoLog.append(this.getClass() + ": " + eccezione.toString() + '\n');
        }
    }

    /**
     * Operazione di modifica dei dati di un cliente già registrato
     * @param idClienteSelezionato Vecchio identificativo del cliente i cui dati vanno modificati
     * @param idCliente Nuovo identificativo del cliente i cui dati vanno modificati
     * @param nomeCliente Nuovo nome del cliente i cui dati vanno modificati
     * @param cognomeCliente Nuovo cognome del cliente i cui dati vanno modificati
     * @param indirizzoCliente Nuovo indirizzo del cliente i cui dati vanno modificati
     */    
    public void AggiornamentoDati (String idClienteSelezionato, String idCliente, String nomeCliente, String cognomeCliente, String indirizzoCliente) {
        try {
            st = miaConnessioneDB.ConnessioneDB().createStatement();
            st.executeUpdate("UPDATE clienti SET id = '" + idCliente + "', nome = '" + nomeCliente + "', cognome = '" + cognomeCliente + "', indirizzo = '" + indirizzoCliente + "' WHERE id = '" + idClienteSelezionato + "'");
            st.close();
            rs.close();
        }
        catch (Exception eccezione) {
            JavaAir.campoLog.append(this.getClass() + ": " + eccezione.toString() + '\n');
        }
    }

    /**
     * Cancellazione dei dati di un cliente già registrato
     * @param idClienteSelezionato Identificativo del cliente da cancellare
     */
    public void CancellazioneDati (String idClienteSelezionato) {
        try {
            st = miaConnessioneDB.connessione.createStatement();
            st.executeUpdate("DELETE FROM clienti WHERE id = '" + idClienteSelezionato + "'");
            st.close();
            rs.close();
        }
        catch (Exception eccezione) {
            JavaAir.campoLog.append(this.getClass() + ": " + eccezione.toString() + '\n');
        }
    }

    /**
     * Metodo che consente di ritornare tutti i dati contenuti nella tabella clienti, ordinata secondo l'identificativo
     * @return dati Matrice contenente tutti i dati contenuti nella tabella clienti
     */
    public String[][] PopolaDatiElencoClienti() {
        try {
            st = miaConnessioneDB.ConnessioneDB().createStatement();
            st.executeQuery("SELECT * FROM clienti ORDER BY id");
            rs = st.getResultSet();

            // Inizializzazione della matrice contenente i dati estratti dal database
            rs.last();
            int righe = rs.getRow();
            int colonne = rs.getMetaData().getColumnCount();
            rs.beforeFirst();

            dati = new String[righe][colonne];

            while (rs.next() == true) {
                // Riempio la tabella con i dati estratti dal database
                for(int i = 0; i < rs.getMetaData().getColumnCount(); i++) {
                    dati[rs.getRow() - 1][i] = rs.getObject(i + 1).toString();
                }
            }
            st.close();
            rs.close();
        }
            catch (Exception eccezione) {
            JavaAir.campoLog.append(this.getClass() + ": " + eccezione.toString() + '\n');
        }
        return dati;
    }
}
