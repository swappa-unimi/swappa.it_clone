/**
 * Progetto di Laboratorio di Programmazione ad Oggetti: classe che consente la creazione della connessione al database contenente tutti i dati
 * @author Mattia Cavenaghi, matricola: 736856
 */

import java.sql.*;

class ConnessioneDB {
    Connection connessione = null;

    /**
     * Metodo che consente all'utente root di creare la connessione al database
     * @return connessione Connessione contenente il riferimento alla connessione avviata
     */

    public Connection ConnessioneDB () {
        try {
            // Caricamento del driver MySql
            Class.forName("com.mysql.jdbc.Driver"); 

            // Connessione dell'utente root al database del progetto
            String url = "jdbc:mysql://localhost/progetto_lpo"; 
            connessione = DriverManager.getConnection(url,"root","");
            }

        catch (Exception eccezione) {
            JavaAir.campoLog.append(this.getClass() + ": " + eccezione.toString() + '\n');
        }
        return connessione;
    }
}
