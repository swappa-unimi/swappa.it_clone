/**
 * Progetto di Laboratorio di Programmazione ad Oggetti: classe che consente la gestione dei dati relativi ai voli effettuati dai clienti
 * @author Mattia Cavenaghi, matricola: 736856
 */

import java.sql.*;
import java.text.*;

class AnagraficaVoli {
    ConnessioneDB miaConnessioneDB = new ConnessioneDB();
    AnagraficaPunti miaAnagraficaPunti = new AnagraficaPunti();
    // Formattatore della data italiana
    DateFormat df = new SimpleDateFormat("dd/mm/yyyy");
    // Formattatore della data MySql
    SimpleDateFormat sdfSql = new SimpleDateFormat("yyyy-mm-dd");

    Statement st = null;
    ResultSet rs = null;
    String [][] dati;

    /**
     * Operazione di registrazione dei dati relativi ad un volo effettuato da un cliente
     * @param idCliente Identificativo del cliente che ha effettuato il volo
     * @param descrizioneVolo Luogo di destinazione del volo
     * @param migliaVolate Lunghezza del volo effettuato
     * @param dataVolo data in cui è stato effettuato il volo
     */
    public void InserimentoDati (String idVolo, String idCliente, String descrizioneVolo, int migliaVolate, Date dataVolo) {
        try {
            st = miaConnessioneDB.ConnessioneDB().createStatement();
            st.executeUpdate("INSERT INTO storico_voli VALUES ('" + idVolo + "', '" + idCliente + "', '" + descrizioneVolo + "', '" + migliaVolate + "', '" + dataVolo + "')");

            st.close();
            rs.close();
        }
        catch (Exception eccezione) {
            JavaAir.campoLog.append(this.getClass() + ": " + eccezione.toString() + '\n');
        }
    }

    /**
     * Operazione di aggiornamento dei dati relativi ad un volo effettuato da un cliente
     * @param idClienteSelezionato Identificativo del cliente selezionato
     * @param idVoloSelezionato Identificativo del volo selezionato
     * @param dataVoloSelezionato Data in cui è stato effettuato il volo selezionato
     * @param idVolo Nuovo identificativo del volo
     * @param idCliente Nuovo identificativo del cliente
     * @param descrizioneVolo Nuova descrizione del volo
     * @param migliaVolate Nuovo valore delle miglia volate
     * @param dataVolo Nuova data in cui è stato effettuato il volo
     */
    public void AggiornamentoDati (String idClienteSelezionato, String idVoloSelezionato, Date dataVoloSelezionato, String idVolo, String idCliente, String descrizioneVolo, int migliaVolate, Date dataVolo) {
        try {
            st = miaConnessioneDB.ConnessioneDB().createStatement();
            st.executeUpdate("UPDATE storico_voli SET id_volo = '" + idVolo + "', id_cliente = '" + idCliente + "', descrizione = '" + descrizioneVolo + "', miglia = '" + migliaVolate + "', data = '" + dataVolo + "' WHERE id_cliente = '" + idClienteSelezionato + "' AND id_volo = '" + idVoloSelezionato + "' AND data = '" + dataVoloSelezionato + "'");
            
            st.close();
            rs.close();
        }
        catch (Exception eccezione) {
            JavaAir.campoLog.append(this.getClass() + ": " + eccezione.toString() + '\n');
        }
    }

    /**
     * Operazione di cancellazione di una tupla dalla tabella dei voli
     * @param idClienteSelezionato Identificativo del cliente che ha effettuato il volo
     * @parma idVoloSelezionato Identificativo del volo selezionato
     * @param dataVoloSelezionato  Data in cui è stato effettuato il volo
     */
    public void CancellazioneDati (String idClienteSelezionato, String idVoloSelezionato, Date dataVoloSelezionato) {
        try {
            st = miaConnessioneDB.ConnessioneDB().createStatement();
            
            // Cancellazione del volo selezionato tramite il selettore di elemento
            st.executeUpdate("DELETE FROM storico_voli WHERE id_volo = '" + idVoloSelezionato + "' AND id_cliente = '" + idClienteSelezionato + "' AND data = '" + dataVoloSelezionato + "'");

            st.close();
            rs.close();
        }
        catch (Exception eccezione) {
            JavaAir.campoLog.append(this.getClass() + ": " + eccezione.toString() + '\n');
        }
    }

    /**
     * Operazione di popolazione dello storico voli
     * @return dati Matrice contenente i dati estratti dal database
     */
    public String [][] PopolaDatiStoricoVoli () {
        try {
            st = miaConnessioneDB.ConnessioneDB().createStatement();
            st.executeQuery("SELECT nome, cognome, id_volo, descrizione, miglia, data FROM clienti JOIN storico_voli WHERE id = id_cliente ORDER BY data, cognome");
            rs = st.getResultSet();

            // Inizializzazione della matrice contenente i dati estratti dal database
            rs.last();
            int righe = rs.getRow();
            int colonne = rs.getMetaData().getColumnCount();
            rs.beforeFirst();

            dati = new String[righe][colonne];

            while (rs.next() == true) {
                // Riempio la tabella con i dati estratti dal database
                for(int i = 0; i < rs.getMetaData().getColumnCount(); i++) {
                    dati[rs.getRow() - 1][i] = rs.getObject(i + 1).toString();
                    if (i == 5)
                        dati[rs.getRow() - 1][i] = df.format(sdfSql.parse(rs.getObject(i + 1).toString()));
                }
            }
            st.close();
            rs.close();
        }
        catch (Exception eccezione) {
            JavaAir.campoLog.append(this.getClass() + ": " + eccezione.toString() + '\n');
        }
        return dati;
    }
    
    /**
     * Operazione di popolazione dello storico occorrenze
     * @return dati Matrice contenente i dati estratti dal database
     */
    public String [][] PopolaDatiStoricoOccorrenze () {
        try {
            st = miaConnessioneDB.ConnessioneDB().createStatement();
            st.executeQuery("SELECT DISTINCT id_cliente, nome, cognome, COUNT(id_cliente) AS occorrenze FROM storico_voli JOIN clienti on id = id_cliente GROUP BY id_cliente ORDER BY id_cliente");
            rs = st.getResultSet();

            rs.last();
            int righe = rs.getRow();
            int colonne = rs.getMetaData().getColumnCount();
            rs.beforeFirst();

            dati = new String[righe][colonne];

            while (rs.next() == true) {
                // Riempio la tabella con i dati estratti dal database
                for(int i = 0; i < rs.getMetaData().getColumnCount(); i++) {
                    dati[rs.getRow() - 1][i] = rs.getObject(i + 1).toString();
                }
            }
            st.close();
            rs.close();
        }
        catch (Exception eccezione) {
            JavaAir.campoLog.append(this.getClass() + ": " + eccezione.toString() + '\n');
        }
        return dati;
    }
}