-- MySQL Administrator dump 1.4
--
-- ------------------------------------------------------
-- Server version	5.0.75-0ubuntu10.2


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


--
-- Create schema progetto_lpo
--

CREATE DATABASE IF NOT EXISTS progetto_lpo;
USE progetto_lpo;
CREATE TABLE  `progetto_lpo`.`clienti` (
  `id` char(10) NOT NULL COMMENT 'Identificativo univoco del cliente',
  `nome` char(25) NOT NULL COMMENT 'Nome del cliente',
  `cognome` char(25) NOT NULL COMMENT 'Cognome del cliente',
  `indirizzo` text NOT NULL COMMENT 'Indirizzo del cliente',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Tabella contenente i dati dei clienti registrati al programm';
CREATE TABLE  `progetto_lpo`.`premi` (
  `id` char(10) NOT NULL COMMENT 'Identificativo del premio',
  `descrizione` text NOT NULL COMMENT 'Descrizione del premio',
  `tipo` set('Buono sconto','Volo gratuito','Soggiorno gratuito') NOT NULL COMMENT 'Tipo di premio (buono sconto, volo gratuito, soggiorno gratuito)',
  `miglia` int(10) unsigned NOT NULL COMMENT 'Miglia necessarie per ritirare il premio',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Tabella dei premi disponibili nel programma JavaAir';
CREATE TABLE  `progetto_lpo`.`storico_premi` (
  `id_cliente` char(10) NOT NULL COMMENT 'Identificativo del cliente che ha ritirato il premio',
  `id_premio` char(10) NOT NULL COMMENT 'Identificativo del premio ritirato dal cliente',
  `data_ritiro` date NOT NULL COMMENT 'Data in cui è stato ritirato il premio',
  PRIMARY KEY  USING BTREE (`id_cliente`,`id_premio`,`data_ritiro`),
  KEY `new_fk_constraint2` (`id_premio`),
  CONSTRAINT `new_fk_constraint1` FOREIGN KEY (`id_cliente`) REFERENCES `clienti` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `new_fk_constraint2` FOREIGN KEY (`id_premio`) REFERENCES `premi` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Tabella contenente la registrazione dei premi ritirati dal c';
CREATE TABLE  `progetto_lpo`.`storico_voli` (
  `id_volo` char(10) NOT NULL COMMENT 'Identificativo univoco del volo.',
  `id_cliente` char(10) NOT NULL COMMENT 'Identificativo del cliente che ha partecipato al volo.',
  `descrizione` text NOT NULL COMMENT 'Descrizione del volo.',
  `miglia` int(10) unsigned NOT NULL COMMENT 'Lunghezza del volo in miglia.',
  `data` date NOT NULL COMMENT 'Data in cui è stato effettuato il volo.',
  PRIMARY KEY  USING BTREE (`id_volo`,`id_cliente`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC COMMENT='Tabella contenente tutti i voli effettuati dai clienti';



/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
