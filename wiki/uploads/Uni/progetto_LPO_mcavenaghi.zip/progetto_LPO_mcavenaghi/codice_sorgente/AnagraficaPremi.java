/**
 * Progetto di Laboratorio di Programmazione ad Oggetti: classe che consente la gestione dei dati relativi ai premi ed alle richieste di premi
 * @author Mattia Cavenaghi, matricola: 736856
 */

import java.sql.*;
import java.text.*;
import java.util.*;

class AnagraficaPremi {
    ConnessioneDB miaConnessioneDB = new ConnessioneDB();
    Statement st = null;
    ResultSet rs = null;
    String [][] dati;
    DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
    SimpleDateFormat sdfSql = new SimpleDateFormat("yyyy-MM-dd");

/**
 * Operazione di inserimento dei dati relativi ad un premio
 * @param idPremio Identificativo del premio
 * @param descrizionePremio Descrizione del premio
 * @param tipoPremio Tipologia di premio (buono sconto, volo gratuito, soggiorno gratuito)
 * @param migliaPremio Quantità di miglia necessarie per ritirare il premio
 */
    public void InserimentoDati (String idPremio, String descrizionePremio, String tipoPremio, int migliaPremio) {
        try {
            st = miaConnessioneDB.ConnessioneDB().createStatement();
            st.executeUpdate("INSERT INTO premi VALUES ('" + idPremio + "', '" + descrizionePremio + "', '" + tipoPremio + "', '" + migliaPremio + "')");

            st.close();
            rs.close();
        }
        catch (Exception eccezione) {
            JavaAir.campoLog.append(this.getClass() + ": " + eccezione.toString() + '\n');
        }
    }

    /**
     * Operazione di modifica dei dati di un premio registrato nel database associato al programma
     * @param idPremioSelezionato Identificativo del premio da aggiornare
     * @param idPremio Nuovo identificativo del premio
     * @param descrizionePremio Nuova descrizione del premio
     * @param tipoPremio Nuova tipologia di premio
     * @param migliaPremio Nuovo valore delle miglia associate al premio
     */
    public void AggiornamentoDati (String idPremioSelezionato, String idPremio, String descrizionePremio, String tipoPremio, int migliaPremio) {
        try {
            st = miaConnessioneDB.connessione.createStatement();
            st.executeUpdate("UPDATE premi SET id = '" + idPremio + "', descrizione = '" + descrizionePremio + "', tipo = '" + tipoPremio + "', miglia = '" + migliaPremio + "' WHERE id = '" + idPremioSelezionato + "'");
            st.close();
            rs.close();
        }
        catch (Exception eccezione) {
            JavaAir.campoLog.append(this.getClass() + ": " + eccezione.toString() + '\n');
        }
    }

    /**
     * Operazione di cancellazione di un premio dal database associato al programma
     * @param idPremioSelezionato Identificativo del premio da cancellare
     */
    public void CancellazioneDati (String idPremioSelezionato) {
        try {
            st = miaConnessioneDB.connessione.createStatement();
            st.executeUpdate("DELETE FROM premi WHERE id = '" + idPremioSelezionato + "'");
            st.close();
            rs.close();
        }
        catch (Exception eccezione) {
            JavaAir.campoLog.append(this.getClass() + ": " + eccezione.toString() + '\n');
        }
    }

    /**
     * Metodo che consente di ritornare tutti i dati contenuti nella tabella clienti, ordinata secondo l'identificativo
     * @return dati Matrice contenente tutti i dati contenuti nella tabella clienti
     */
    public String[][] PopolaDatiElencoPremi() {
        try {
            st = miaConnessioneDB.ConnessioneDB().createStatement();
            st.executeQuery("SELECT * FROM premi ORDER BY miglia");
            rs = st.getResultSet();

            // Inizializzazione della matrice contenente i dati estratti dal database
            rs.last();
            int righe = rs.getRow();
            int colonne = rs.getMetaData().getColumnCount();
            rs.beforeFirst();

            dati = new String[righe][colonne];

            while (rs.next() == true) {
                // Riempio la tabella con i dati estratti dal database
                for(int i = 0; i < rs.getMetaData().getColumnCount(); i++) {
                    dati[rs.getRow() - 1][i] = rs.getObject(i + 1).toString();
                }
            }
            st.close();
            rs.close();
        }
        catch (Exception eccezione) {
            JavaAir.campoLog.append(this.getClass() + ": " + eccezione.toString() + '\n');
        }
        return dati;
    }

    /**
     * Metodo che consente di ritornare i dati relativi ai premi ritirati dai clienti
     * @return dati Matrice contenente tutti i dati associati al ritiro dei premi
     */
    public String[][] PopolaDatiStoricoPremi () {
        try {
            st = miaConnessioneDB.ConnessioneDB().createStatement();
            st.executeQuery("SELECT id_cliente, nome, cognome, id_premio, descrizione, miglia, data_ritiro FROM premi JOIN storico_premi JOIN clienti ON premi.id = id_premio AND id_cliente = clienti.id ORDER BY clienti.id, data_ritiro");
            rs = st.getResultSet();

            // Inizializzazione della matrice contenente i dati estratti dal database
            rs.last();
            int righe = rs.getRow();
            int colonne = rs.getMetaData().getColumnCount();
            rs.beforeFirst();

            dati = new String[righe][colonne];

            while (rs.next() == true) {
                // Riempio la tabella con i dati estratti dal database
                for(int i = 0; i < rs.getMetaData().getColumnCount(); i++) {
                    dati[rs.getRow() - 1][i] = rs.getObject(i + 1).toString();

                if (i == 6)
                    dati[rs.getRow() - 1][i] = df.format(sdfSql.parse(rs.getObject(i + 1).toString()));
                }
            }
            st.close();
            rs.close();
        }
        catch (Exception eccezione) {
            JavaAir.campoLog.append(this.getClass() + ": " + eccezione.toString() + '\n');
        }
        return dati;
    }

    /**
     * Metodo consente di associare ad un cliente il premio ritirato
     * @param idClienteSelezionato Identificativo del cliente che ha ritirato il premio
     * @param idPremioSelezionato Identificativo del premio ritirato dal cliente
     * @param dataRitiro Data in cui è stato ritirato il premio
     */
    public void InserimentoDatiRichiestaPremio (String idClienteSelezionato, String idPremioSelezionato, java.sql.Date dataRitiro) {
        try {
            Calendar dataFine = Calendar.getInstance();
            Calendar dataInizio = Calendar.getInstance();
            // Calcolo della data odierna rispetto a cinque anni fa
            dataInizio.add(Calendar.YEAR, -5);

            int puntiPremi = 0;
            int puntiDisponibili = 0;

            st = miaConnessioneDB.ConnessioneDB().createStatement();
            
            // Selezione del numero di punti associati al premio selezionato
            st.executeQuery("SELECT miglia FROM premi WHERE id = '" + idPremioSelezionato + "'");
            rs = st.getResultSet();

            while (rs.next())
                puntiPremi += Integer.parseInt(rs.getObject(1).toString());


            // Selezione del numero di punti spesi dal cliente
            st.executeQuery("SELECT SUM(miglia) FROM storico_premi JOIN premi ON id_premio = id WHERE id_cliente = '" + idClienteSelezionato + "' AND data_ritiro BETWEEN '" + sdfSql.format(dataInizio.getTime()) + "' AND '" + sdfSql.format(dataFine.getTime()) + "'");
            rs = st.getResultSet();

            while (rs.next()) {
                rs.getObject(1);
                if (rs.wasNull())
                    puntiPremi += 0;
                else
                    puntiPremi += Integer.parseInt(rs.getObject(1).toString());
            }

            // Selezione del numero dei punti posseduti dal cliente (i punti sono riferiti ad un arco di tempo compreso tra l'oggi e cinque anni precedenti)
            st.executeQuery("SELECT DISTINCT SUM(miglia) FROM storico_voli JOIN clienti ON id = id_cliente WHERE data BETWEEN '" + sdfSql.format(dataInizio.getTime()) + "' AND '" + sdfSql.format(dataFine.getTime()) + "' AND id_cliente = '" + idClienteSelezionato + "' GROUP BY id_cliente ORDER BY id_cliente");
            rs = st.getResultSet();

            while (rs.next()) {
                rs.getObject(1);
                if (rs.wasNull())
                    puntiDisponibili += 0;
                else
                    puntiDisponibili += Integer.parseInt(rs.getObject(1).toString());
            }

            // Condizione per cui è possibile o meno al cliente di ritirare il premio
            if (puntiDisponibili < puntiPremi)
                JavaAir.campoLog.append("Il cliente selezionato non ha punti a sufficienza per ritirare il premio selezionato." + '\n');
            else
                st.executeUpdate("INSERT INTO storico_premi VALUES ('" + idClienteSelezionato + "', '" + idPremioSelezionato + "', '" + dataRitiro + "')");

            st.close();
            rs.close();
        }
        catch (Exception eccezione) {
            JavaAir.campoLog.append(this.getClass() + ": " + eccezione.toString() + '\n');
        }
    }

    /**
     * Metodo che consente di aggiornare i dati relativi ad un premio già ritirato da un cliente
     * @param idNuovoCliente Nuovo identificativo del cliente che ha ritirato il premio
     * @param idNuovoPremio Nuovo identificativo del premio ritirato
     * @param dataNuovoRitiro Nuova data di ritiro del premio
     * @param idClienteSelezionato Vecchio identificativo del cliente da modificare
     * @param idPremioSelezionato Vecchio identificativo del premio da ritirare
     * @param dataRitiroSelezionata Vecchia data in cui è stato ritirato il premio
     */
    public void AggiornamentoDatiRichiestaPremio (String idNuovoCliente, String idNuovoPremio, java.sql.Date dataNuovoRitiro, String idClienteSelezionato, String idPremioSelezionato, java.sql.Date dataRitiroSelezionata) {
        try {
            st = miaConnessioneDB.connessione.createStatement();
            //st.executeUpdate("UPDATE storico_premi SET id_cliente = '" + idNuovoCliente + "', id_premio = ' " + idNuovoPremio + " ', data_ritiro = '" + dataNuovoRitiro + "' WHERE id_cliente = '" + idClienteSelezionato + "' AND id_premio = ' " + idPremioSelezionato + " ' AND data_ritiro = '" + dataRitiroSelezionata + "'");
            // Correzione: il valore dell'id_premio ha degli spazi aggiuntivi da eliminare
            st.executeUpdate("UPDATE storico_premi SET id_cliente = '" + idNuovoCliente + "', id_premio = '" + idNuovoPremio + "', data_ritiro = '" + dataNuovoRitiro + "' WHERE id_cliente = '" + idClienteSelezionato + "' AND id_premio = '" + idPremioSelezionato + "' AND data_ritiro = '" + dataRitiroSelezionata + "'");
            
            st.close();
            rs.close();
        }
        catch (Exception eccezione) {
            JavaAir.campoLog.append(this.getClass() + ": " + eccezione.toString() + '\n');
        }
    }

    /**
     * Metodo che consente di rimuovere un premio associato ad un cliente
     * @param idClienteSelezionato Identificativo del cliente il cui premio va rimosso
     * @param idPremioSelezionato Identificativo del premio da rimuovere
     * @param dataRitiroSelezionata Data in cui è stato ritirato il premio da rimuovere
     */
    public void CancellazioneDatiRichiestaPremio (String idClienteSelezionato, String idPremioSelezionato, java.sql.Date dataRitiroSelezionata) {
        try {
            st = miaConnessioneDB.connessione.createStatement();
            st.executeUpdate("DELETE FROM storico_premi WHERE id_cliente = '" + idClienteSelezionato + "' AND id_premio = '" + idPremioSelezionato + "' AND data_ritiro = '" + dataRitiroSelezionata + "'");

            st.close();
            rs.close();
        }
        catch (Exception eccezione) {
            JavaAir.campoLog.append(this.getClass() + ": " + eccezione.toString() + '\n');
        }
    }
}