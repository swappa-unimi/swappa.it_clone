/**
 * Progetto di Laboratorio di Programmazione ad Oggetti: classe che consente la gestione dei punti associati ai clienti
 * @author Mattia Cavenaghi, matricola: 736856
 */

import java.sql.*;
import java.text.*;
import java.util.*;

class AnagraficaPunti {
    ConnessioneDB miaConnessioneDB = new ConnessioneDB();
    Statement st = null;
    ResultSet rs = null;
    // Formattatore data italiana
    DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
    // Formattatore data MySql
    SimpleDateFormat sdfSql = new SimpleDateFormat("yyyy-MM-dd");
    
    String [][] dati;

    /**
     * Operazione di estrazione del numero di punti associati ad un cliente, dei punti spesi e della fascia di appartenenza
     * @return dati Matrice contenente i dati estratti dal DB
     */
    public String[][] PopolaDatiStoricoPunti () {
        try {
            // Cattura della data odierna
            Calendar dataFine = Calendar.getInstance();
            Calendar dataInizio = Calendar.getInstance();
            Calendar dataInizio2 = Calendar.getInstance();
            // Calcolo della data odierna rispetto a cinque anni fa
            dataInizio.add(Calendar.YEAR, -5);
            // Calcolo della data odierna rispetto ad un anno fa
            dataInizio2.add(Calendar.YEAR, -1);

            st = miaConnessioneDB.ConnessioneDB().createStatement();
            // Seleziono i dati dei clienti che hanno accumulato punti dalla data odierna fino a cinque anni prima
            st.executeQuery("SELECT DISTINCT clienti.id, nome, cognome, SUM(storico_voli.miglia) FROM storico_voli JOIN clienti ON (clienti.id = storico_voli.id_cliente) WHERE data BETWEEN '" + sdfSql.format(dataInizio.getTime()) + "' AND '" + sdfSql.format(dataFine.getTime()) + "' GROUP BY storico_voli.id_cliente ORDER BY storico_voli.id_cliente");
            rs = st.getResultSet();

            // Selezione dei punti spesi dal cliente negli ultimi cinque anni
            Statement st2 = miaConnessioneDB.ConnessioneDB().createStatement();
            ResultSet rs2 = null;
            st2.executeQuery("SELECT DISTINCT id_cliente, SUM(miglia) FROM storico_premi JOIN premi ON id_premio = premi.id WHERE data_ritiro BETWEEN '" + sdfSql.format(dataInizio.getTime()) + "' AND '" + sdfSql.format(dataFine.getTime()) + "' GROUP BY id_cliente ORDER BY id_cliente");
            rs2 = st2.getResultSet();

            // Selezione dei punti accumulati nell'ultimo anno solare, per il calcolo della fascia da associare al cliente
            Statement st3 = miaConnessioneDB.ConnessioneDB().createStatement();
            ResultSet rs3 = null;
            st3.executeQuery("SELECT DISTINCT id_cliente, SUM(miglia) FROM storico_voli WHERE data BETWEEN '" + sdfSql.format(dataInizio2.getTime()) + "' AND '" + sdfSql.format(dataFine.getTime()) + "' GROUP BY id_cliente ORDER BY id_cliente");
            rs3 = st3.getResultSet();

            // Inizializzazione della matrice contenente i dati estratti dal database
            rs.last();
            int righe = rs.getRow();
            // Conteggio due colonne in più per inserire i punti spesi e la fascia
            int colonne = rs.getMetaData().getColumnCount() + 2;
            rs.beforeFirst();

            dati = new String[righe][colonne];

            while (rs.next() == true) {
                // Riempio la tabella con i dati estratti dal database
                for(int i = 0; i < rs.getMetaData().getColumnCount(); i++) {
                    dati[rs.getRow() - 1][i] = rs.getObject(i + 1).toString();

                    // Inizializzazione della fascia ad 1 per tutti i clienti
                    dati[rs.getRow() - 1][colonne - 1] = "1";

                    // Calcolo dei punti rimanenti associati ad ogni cliente...
                    if (i == rs.getMetaData().getColumnCount() - 2) {
                        while (rs2.next() == true) {
                            for (int j = 0; j < rs2.getMetaData().getColumnCount(); j++) {
                                // ... comparazione dei codici cliente delle due query eseguite in precedenza...
                                if (rs.getObject(1).toString().equals(rs2.getObject(1).toString())) {
                                        // ... calcolo della differenza tra i punti acquisiti dal cliente ed i punti spesi...
                                        dati[rs.getRow() - 1][colonne - 2] = String.valueOf(Integer.parseInt(rs.getObject(4).toString()) -  Integer.parseInt(rs2.getObject(2).toString()));
                                }
                            }
                        }
                    }
                    // ... calcolo della fascia da associare ai clienti, in base alla quantità di punti acquisiti nell'anno solare...
                    if (i == rs.getMetaData().getColumnCount() - 1) {
                        while (rs3.next() == true) {
                            for (int j = 0; j < rs3.getMetaData().getColumnCount(); j++) {
                                // ... comparazione dei codici cliente delle due query eseguite in precedenza...
                                if (rs.getObject(1).toString().equals(rs3.getObject(1).toString())) {
                                    int fascia;
                                    // ... calcolo della fascia.
                                    if (Integer.parseInt(rs3.getObject(2).toString()) < 35000)
                                        fascia = 1;
                                    else if (Integer.parseInt(rs3.getObject(2).toString()) < 100000)
                                        fascia = 2;
                                    else
                                        fascia = 3;
                                    
                                    dati[rs.getRow() - 1][colonne - 1] = String.valueOf(fascia);
                                }
                            }
                        }
                    }
                    rs2.beforeFirst();
                    rs3.beforeFirst();
                }
            }

            st.close();
            rs.close();
            st2.close();
            rs2.close();
            st3.close();
            rs3.close();

            // Assegnazione ai punti rimanenti nulli, il valore dei punti guadagnati (il cliente non ha ritirato premi)
            for (int i = 0; i < righe; i++)
                if (dati[i][4] == null)
                    dati[i][4] = dati[i][3];
        }
        catch (Exception eccezione) {
            JavaAir.campoLog.append(this.getClass() + ": " + eccezione.toString() + '\n');
        }
        return dati;
    }
}