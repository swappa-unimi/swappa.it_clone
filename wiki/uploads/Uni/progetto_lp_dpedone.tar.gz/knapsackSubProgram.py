# ---------Author: Davide Pedone----------
# ---------------Matr 809468--------------
# -----davide.pedone@studenti.unimi.it----
# ----------The Knapsack Problem----------

import threading

# array con i pesi degli oggetti
w = [0, 2, 31, 4, 10, 8, 9, 6, 7, 3]
# array con i valori degli oggetti
p = [0, 2, 3, 4, 1, 8, 9, 6, 7, 3]
# capacità massima dello zaino
C = 20

# creo una tabella per i risultati
f = [ [ 0 for i in range(0,C+1) ] for j in range(0,len(p)) ]

# creo un dizionario in cui salvare le conditions dei thread
cond = {}

for k in range(0,len(p)):
    for c in range(C+1):
		threadName = '%d@%d' %(k,c)
		cond[threadName] = threading.Event()

# utilizzo la parallelizzazione tramite concorrenza a livello di sottoprogrammi
def statement(f,k,c):
	
	current = '%d@%d' %(k,c)
	# calcolo quali sono i thread che devo aspettare
	previous1 = '%d@%d' %(k-1,c)
	previous2 = '%d@%d' %(k-1,c-w[k])
	
	if(w[k]>c):
		# devo aspettare solo un thread, quello di (k-1,c)
		cond[previous1].wait()
		f[k][c] = f[k-1][c]
	else:
		# devo aspettare due thread, (k-1,c) e (k-1,c-w[k])
		cond[previous1].wait()
		cond[previous2].wait()
		f[k][c] = max(f[k-1][c],p[k]+f[k-1][c-w[k]])
		
	# con questo thread ho finito, setto il suo flag a true.
	# Ora chi sta aspettando questo thread parte
	cond[current].set()

# calcolo tutti i possibili valori
for k in range(0,len(p)):
    for c in range(C+1):
        threadName = '%d@%d' %(k,c)
	if k==0:
		# non faccio partire nessun thread, so gia' che f(k,c)=0 se k=0
		# setto il flag a true, cosi' nessun thread che chiama f[0][c] deve aspettare
		cond[threadName].set()
	else:
		# faccio partire un thread per ogni valore di (k,c)
		t = threading.Thread(name=threadName,target=statement,args=(f,k,c,))
		t.start()

# stampo la tabella finale
for row in f:
    print row

# stampo massimo valore di p che posso inserire nello Zaino
print f[len(p)-1][C]

