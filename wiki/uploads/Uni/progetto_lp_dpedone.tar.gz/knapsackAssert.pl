% ---------Author: Davide Pedone----------
% ---------------Matr 809468--------------
% -----davide.pedone@studenti.unimi.it----
% ----------The Knapsack Problem----------

% lista con i pesi degli oggetti
w([0,2,31,4,10,8,9,6,7,3]).
% lista con i valori degli oggetti
p([0,2,3,4,1,8,9,6,7,3]).
% capacit� massima dello zaino
c(20).

% dichiaro knapsack come dynamic cos� posso modificarlo a runtime
:- dynamic knapsack/3.

% definisco il caso base, f(k,c) = 0 se k<=0
knapsack(K,C,F) :-
	K =< 0,
	F is 0,
	asserta(knapsack(K,C,F):-!). % scrivo il risultato sul db

% se w[k]>c allora f(k,c) = f(k-1,c)
knapsack(K,C,F) :-
	K>0,
	w(W), % recupero la lista dei pesi
	nth0(K,W,X), % calcolo w[k]
	X>C, K1 is K-1,
	knapsack(K1,C,F). % ricorsione

% se w[k]<=c allora f(k,c) = max(f(k-1,c),p[k]+f(k-1,c-w[k])
knapsack(K,C,F) :-
	K>0,
	w(W),p(P), % recupero la lista dei pesi e dei valori
	nth0(K,W,X), nth0(K,P,Y), % recupero w[k] e p[k]
	K1 is K-1, C1 is C-X,
	knapsack(K1,C,T1), % ricorsione, calcolo il primo elemento da confrontare
	knapsack(K1,C1,T2), T3 is Y + T2, % ricorsione, calcolo il secondo elemento da confrontare
	F is max(T1,T3),
	asserta(knapsack(K,C,F):-!). % scrivo il risultato sul db

% fine della ricorsione, scrivo il risultato sul db
knapsack(K,C,F) :- 	asserta(knapsack(K,C,F):-!).