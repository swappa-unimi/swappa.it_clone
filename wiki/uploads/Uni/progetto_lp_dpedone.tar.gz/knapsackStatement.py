# ---------Author: Davide Pedone----------
# ---------------Matr 809468--------------
# -----davide.pedone@studenti.unimi.it----
# ----------The Knapsack Problem----------

import threading

# array con i pesi degli oggetti
w = [0, 2, 31, 4, 10, 8, 9, 6, 7, 3]
# array con i valori degli oggetti
p = [0, 2, 3, 4, 1, 8, 9, 6, 7, 3]
# capacità massima dello zaino
C = 20

# creo un dizionario in cui salvare le conditions dei k thread
kThreadCondition = {}
for k in range(0,len(p)):
	threadName = 'line-%d' %(k)
	kThreadCondition[threadName] = threading.Event()

# creo un array in cui tenere traccia di quanti valori di c ho calcolato
cCounter = [0]*len(p)
		
# creo una tabella per i risultati
f = [ [ 0 for i in range(0,C+1) ] for j in range(0,len(p)) ]

# utilizzo la parallelizzazione tramite concorrenza a livello di sottoprogrammi
def statement(f,k,c):
	if(w[k]>c):
		f[k][c] = f[k-1][c]
	else:
		f[k][c] = max(f[k-1][c],p[k]+f[k-1][c-w[k]])
	# ho calcolato un valore di c, aumento il contatore
	cCounter[k] = cCounter[k]+1
	# se per questo valore di k cCounter vale C vuole dire che ho finito di calcolare questa riga, quindi 
	# posso settare il flag di questo kThread a true e far partire il successivo
	if cCounter[k] == C:
		threadName = 'line-%d' %(k)
		kThreadCondition[threadName].set()
		
# dato k faccio partire un thread per ogni valore di c. non mi preoccupo della sincronizzazione di questi thread
# perche' fissato k tutti i C valori di f(k,c), 0 < c < C possono essere calcolati indipendentemente
def processLine(k):
	for c in range(C+1):
		cThread = threading.Thread(target=statement,args=(f,k,c,))
		cThread.start()

# faccio partire un thread per ogni valore di k. se k==1 non devo aspettare che
# il kThread precendente abbia finito, so gia' che f(k,c)=0 se k=0.
# se k!=1 aspetto il thread della riga precedente
for k in range(1,len(p)):
	threadName = 'line-%d' %(k)
	if k!=1:
		waitFor =  'line-%d' %(k-1)
		kThreadCondition[waitFor].wait()
	kThread = threading.Thread(name=threadName,target=processLine,args=(k,))
	kThread.start()
		
# stampo la tabella finale
waitToPrint = 'line-%d' %(len(p)-1)
kThreadCondition[waitToPrint].wait()
for row in f:
    print row

# stampo massimo valore di p che posso inserire nello Zaino
print f[len(p)-1][C]
