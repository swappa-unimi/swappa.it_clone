-- MySQL dump 10.13  Distrib 5.1.39, for pc-linux-gnu (i686)
--
-- Host: localhost    Database: progetto_tw
-- ------------------------------------------------------
-- Server version	5.1.39

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `recensioni`
--

DROP TABLE IF EXISTS `recensioni`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recensioni` (
  `riferimento` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Riferimento numerico univoco della recensione',
  `autore_opera` char(50) NOT NULL COMMENT 'Autore dell''opera recensita',
  `titolo` varchar(100) NOT NULL COMMENT 'Titolo dell''opera recensita',
  `data_pubblicazione_recensione` date NOT NULL COMMENT 'Data di pubblicazione dell''opera recensita',
  `testo` text NOT NULL COMMENT 'Testo dell''opera recensita',
  `nome_file` varchar(100) NOT NULL COMMENT 'Nome del file che raffigura l''opera recensita',
  `voto` int(10) unsigned NOT NULL COMMENT 'Voto dell''opera recensita',
  `editore` char(50) DEFAULT NULL COMMENT 'Editore che ha pubblicato l''opera',
  `anno_pubblicazione_opera` int(10) unsigned DEFAULT NULL COMMENT 'Anno di pubblicazione dell''opera',
  `autore_recensione` varchar(20) NOT NULL COMMENT 'Nickname dell''autore della recensione',
  PRIMARY KEY (`riferimento`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `utenti`
--

DROP TABLE IF EXISTS `utenti`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `utenti` (
  `nickname` varchar(20) NOT NULL COMMENT 'Username dell''utente registrato al sito',
  `password` varchar(20) NOT NULL COMMENT 'Password di accesso al sito',
  `nome` char(20) DEFAULT NULL COMMENT 'Nome dell''utente',
  `cognome` char(20) DEFAULT NULL COMMENT 'Cognome dell''utente',
  `email` varchar(50) NOT NULL COMMENT 'E-mail dell''utente',
  `generi` text COMMENT 'Genere/i di libro/i selezionato/i dall''utente',
  PRIMARY KEY (`nickname`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=FIXED COMMENT='Tabella contenente i dati degli utenti';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2010-01-10 20:11:28
