/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pack;

import java.sql.*;

import java.util.Vector;

/**
 * Pagamento - Classe contenenti i dati relativi a un pagamento
 * 
 */
public class Pagamento {

    //variabili di classe
    private String codice;
    private String data;
    private double importo;
    private String nominativo;

    //costruttore
    public Pagamento() {
    }

    /**
     * restituisce il codice del pagamento
     * @return codice
     */
    public String getCodice() {
        return codice;
    }

    /**
     * inserisce il codice del pagamento
     * @param codice
     */
    public void setCodice(String codice) {
        this.codice = codice;
    }

    /**
     * restituisce la data del pagamento
     * @return data
     */
    public String getData() {
        return data;
    }

    /**
     * inserisce la data del pagamento
     * @param data
     */
    public void setData(String data) {
        this.data = data;
    }

    /**
     * restituisce l'importo del pagamento
     * @return importo
     */
    public double getImporto() {
        return importo;
    }

    /**
     * inserisce l'importo dl pagamento
     * @param importo
     */
    public void setImporto(double importo) {
        this.importo = importo;
    }

    /**
     * restituisce il nome del proprietario che ha effettuato il pagamento
     * @return nominativo
     */
    public String getNominativo() {
        return nominativo;
    }

    /**
     * inserisce il nome del proprietario che ha effettuato il pagamento
     * @param nominativo
     */
    public void setNominativo(String nominativo) {
        this.nominativo = nominativo;
    }

    /**
     * effettua il pagamento da parte di un proprietario incrementando il
     * saldo relativo
     * @param elProp un Vector di oggetti Proprietario
     */
    public void effettuaPagamento(Vector<Proprietario> elProp) {

       for (int i = 0; i < elProp.size(); i++) {
            if(this.nominativo.equalsIgnoreCase(elProp.get(i).getNome())){
                elProp.get(i).setSaldo(elProp.get(i).getSaldo()+this.importo);
                break;
            }
        }
    }

    //interrogazione e update DB
    /**
     * effettua la lettura della tabella PAGAMENTI. ogni record (e i relativi campi)
     * è inserito in oggetto Pagamento, a sua volta inserito in un Vector di
     * oggetti Pagamento
     * @return un Vector di oggetti Pagamento
     * @param conn un oggetto Connection
     */
    public static Vector<Pagamento> readDB(Connection conn) throws SQLException {
        Statement st;
        ResultSet rs;
        Vector<Pagamento> vPag = new Vector<Pagamento>();
        st = conn.createStatement();
        rs = st.executeQuery("select * from condominio.pagamenti");
        while (rs.next()) {
            Pagamento tmp = new Pagamento();
            tmp.setCodice(rs.getString("id"));
            tmp.setData(rs.getString("data"));
            tmp.setImporto(rs.getDouble("importo"));
            tmp.setNominativo(rs.getString("nominativo"));
            vPag.add(tmp);
        }
        st.close();
        rs.close();
        return (vPag);
    }

    /**
     * scrive su DB i cambiamenti apportati al Vector di oggetti Spesa, ovvero
     * inserisce una nuova spesa nel DB.
     * @param elPag un Vector di oggetti PAgamento
     * @param conn un oggetto Connection
     * @throws SQLException
     */
    public static void updateDB(Vector<Pagamento> elPag, Connection conn, int pos) throws SQLException {
        Statement st;
        st = conn.createStatement();
        if (elPag.size() > pos) {
            for (int i = pos; i < elPag.size(); i++) {
                String qIns = "insert into condominio.pagamenti values('"+elPag.get(i).getCodice()+"','" + Controlli.formatDate(elPag.get(i).getData())+ "','"+elPag.get(i).getNominativo()+"',"+elPag.get(i).getImporto()+")";
                st.addBatch(qIns);
            }
            boolean chk = true;
            int i = 0;
            int[] res = st.executeBatch();
            while (i < res.length && !chk) {
                if (res[i] < 0) {
                    chk = false;
                }
            }

            if (chk) {
                System.out.println("update tabella PAGAMENTI effettuato correttamente");
            } else {
                System.out.println("errore nell'update della tabella pagamenti!");
            }
        }

        st.close();
    }
}//controllato

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


