/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package pack;

import java.math.BigDecimal;
import java.sql.*;
import java.util.Calendar;



/**
 * Controlli - Classe contenente metodi statici per vari controlli
 * 
 */
public class Controlli {

    /**
     * routine per la connesione a DB
     * @return un oggetto di tipo Connection
     */
    public static Connection getDBconnection() {

        Connection cn = null;

        try {

            Class.forName("com.mysql.jdbc.Driver").newInstance();

        } catch (ClassNotFoundException ex) {
            System.out.println("Classe non trovata. eccezione: " + ex);
        } catch (InstantiationException ex) {
            System.out.println("Errore creazione istanza classe. eccezione: " + ex);
        } catch (IllegalAccessException ex) {
            System.out.println("Accesso illegale. eccezione: " + ex);
        }
        String url = "jdbc:mysql://localhost:3306/mysql";
        String user = "root";
        String passw = "xxxxx.32";
        try {

            cn = DriverManager.getConnection(url, user, passw);
           // System.out.println("sono dopo connessione");

        } catch (SQLException e1) {
            System.out.println("errore: " + e1);
        }
        return (cn);
    }



     /**
     * routine per il controllo della validità e del formato data (gg/mm/aaaa)
     * @param  data una stringa rappresentante la data da verificare
     * @return TRUE se la data e il formato sono validi (gg/mm/aaaa), FALSE altrimenti
     */
    public static boolean checkDate (String data){
        int gg = Integer.parseInt(data.substring(0,2));
        int mm = Integer.parseInt(data.substring(3,5));
        int aaaa = Integer.parseInt(data.substring(6,10));
        Calendar calendario = Calendar.getInstance();
        boolean check1, check2, check3, check_f, ok;


        check_f=check1=check2=check3=ok=false;
        int cd = calendario.get(Calendar.DAY_OF_MONTH);
        int cm = calendario.get(Calendar.MONTH);
        int cy = calendario.get(Calendar.YEAR);
        if((gg>=1)&&(gg<=cd)) check1 = true;
        if(!check1 && (mm>=1) && (mm<=(cm+1))) check2 = true;
        if(!check2 && (aaaa>=1970) && (aaaa<=cy)) check3 = true;
        char f = data.charAt(2);
        char l = data.charAt(5);
        if(f=='/' && l=='/')check_f=true;

        if(check3&&check_f)ok=true;

        if(ok)  return(true);
        else{
            System.out.println("errore: data non valida o formato errato.");
            return (false);
        }

    }
    
    /*
     * routine controllo date corretta e aggiunta successivamente (ma non utilizzata)
     */
//     public static boolean checkDate2 (String data){
//        int gg = Integer.parseInt(data.substring(0,2));
//        int mm = Integer.parseInt(data.substring(3,5));
//        int aaaa = Integer.parseInt(data.substring(6,10));
//        Calendar day = Calendar.getInstance();
//        day.set(Calendar.YEAR, aaaa);
//        day.set(Calendar.MONTH, (mm-1));
//        day.set(Calendar.DAY_OF_MONTH, gg);
//
//        boolean ok;
//
//        Calendar calendario = Calendar.getInstance();
//        int cd = calendario.get(Calendar.DAY_OF_MONTH);
//        int cm = calendario.get(Calendar.MONTH);
//        int cy = calendario.get(Calendar.YEAR);
//
//        Calendar currDate = Calendar.getInstance();
//        currDate.set(Calendar.YEAR, cy);
//        currDate.set(Calendar.MONTH, cm);
//        currDate.set(Calendar.DAY_OF_MONTH, cd);
//
//        char f = data.charAt(2);
//        char l = data.charAt(5);
//
//
//        long dist = currDate.getTimeInMillis() - day.getTimeInMillis();
//
//        if((f=='/' && l=='/')&&(dist>=0)) ok = true;
//        else{
//            ok = false;
//            System.out.println("Data scorretta. riprovare");
//        }
//
//        return (ok);
//    }
        





    /**
     * routine per l'arrotondamento per eccesso di un double
     * @param d il double da arrotondare
     * @param posDec un intero rappresentante quante cifre seguiranno dopo la virgola
     * @return un double p arrotondato
     */
     public static double arrotonda (double d, int posDec){
            BigDecimal bd = new BigDecimal(d);
            bd = bd.setScale(posDec, BigDecimal.ROUND_HALF_UP);
            double p = bd.doubleValue();
            return (p);

        }

//aggiunta dopo il cambio di database da Oracle a MySQL

     /**
      * routine per la corretta formattazione delle date (aaaa-mm-gg) per l'inserimento nel db MySQL
      * @param data la data (String) da formattare (IMPORTANTE: in formato gg/mm/aaaa)
      * @return la data (String) formattata correttamente
      */
     public static String formatDate(String data){
         String dd = data.substring(0,2);
         String mm = data.substring(3,5);
         String yyyy = data.substring(6,10);
         return(yyyy+"-"+mm+"-"+dd);
     }


}
