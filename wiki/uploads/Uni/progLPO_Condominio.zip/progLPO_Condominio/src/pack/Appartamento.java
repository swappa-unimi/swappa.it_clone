/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package pack;

import java.sql.*;
import java.util.Vector;

/**
 * Appartamento - Classe contenenti i dati relativi a un appartamento
 * 
 */
public class Appartamento {

    //variabili di classe
    private String codice;
    private String proprietario;
    private double superficie;
    private String inquilino;
    private int numvani;
    private Vector<String> speseSostenute;

    //costruttore
    public Appartamento() {
    }


    //metodi di istanza

    /**
     * ritorna il codice di un appartamento
     * @return codice
     */
    public String getCodice() {
        return codice;
    }

    /**
     * inserisce il codice dell'appartamento
     * @param codice
     */
    public void setCodice(String codice) {
        this.codice = codice;
    }


    /**
     * restituisce il nome dell'inquilino
     * @return inquilino
     */
    public String getInquilino() {
        return inquilino;
    }


    /**
     * inserisce il nome dell'inquilino
     * @param inquilino
     */
    public void setInquilino(String inquilino) {
        this.inquilino = inquilino;
    }

    /**
     * restituisce il numero di locali
     * @return numvani
     */
    public int getNumvani() {
        return numvani;
    }

    /**
     * inserisce il numero di locali
     * @param numvani
     */
    public void setNumvani(int numvani) {
        this.numvani = numvani;
    }

    /**
     * restituisce il nome del proprietario
     * @return proprietario
     */
    public String getProprietario() {
        return proprietario;
    }


    /**
     * inserisce il nome del proprietario
     * @param proprietario
     */
    public void setProprietario(String proprietario) {
        this.proprietario = proprietario;
    }

    /**
     * restituisce le spese sostenute dal proprietario per questo appartamento
     * @return speseSostenute
     */
    public Vector<String> getSpeseSostenute() {
        return speseSostenute;
    }

    /**
     * inserisce le spese sostenute dal proprietario per questo appartamento
     * @param speseSostenute
     */
    public void setSpeseSostenute(Vector<String> speseSostenute) {
        this.speseSostenute = speseSostenute;
    }

    /**
     * restituisce la superficie dell'appartamento (mq)
     * @return superficie
     */
    public double getSuperficie() {
        return superficie;
    }

    /**
     * inserisce la superficie dell'appartamento
     * @param superficie
     */
    public void setSuperficie(double superficie) {
        this.superficie = superficie;
    }

    /**
     * aggiunge la spesa all'elenco di spese sostenute
     * @param codSpesa una stringa contenente il codice identificativo della spesa
     */
    public void addToSpeseSostenute(String codSpesa){
        this.speseSostenute.add(codSpesa);
    }

    /**
     * stampa l'elenco delle spese sostenute dall'appartamento, con relativa tipologia
     * @param elSpese un oggetto Vector contenente gli oggetti Spesa
     */
    public void elencaSpese(Vector<Spesa> elSpese, Vector<SpesaSpeciale> elSpeseSpec){
        for (int i = 0; i < elSpese.size(); i++) {
            Spesa tmp = elSpese.get(i);
            for (int j = 0; j < this.speseSostenute.size(); j++) {
                if(tmp.getCodice().equalsIgnoreCase(this.speseSostenute.get(j))){
                    System.out.println("codice spesa: "+this.speseSostenute.get(j)
                                     +"\t tipologia: "+tmp.getTipo());
                }
            }
        }
        System.out.println("SPESE SPECIALI:");
        for (int i = 0; i < this.speseSostenute.size(); i++) {
            for (int j = 0; j < elSpeseSpec.size(); j++) {
                if(this.speseSostenute.get(i).equalsIgnoreCase(elSpeseSpec.get(j).getCodice())){
                    System.out.println("codice spesa: "+this.speseSostenute.get(i)+"\t tipologia: "+elSpeseSpec.get(j).getTipo()+"\t importo: "+elSpeseSpec.get(j).getImporto()+" euro");
                }


            }
        }
    }

    /**
     * cambia il nome del proprietario di questo oggetto Appartamento e
     * del campo nome dell'oggetto Proprietario corrispondente
     * @param nuovoProp una stringa contenente il nome del nuovo proprietario
     * @param elProp un Vector di oggetti Proprietario
     */
    public void cambiaProprietario(String nuovoProp, Vector<Proprietario> elProp){

        boolean stop = false;

        String oldProp = this.proprietario;
        this.proprietario=nuovoProp;
        for (int i = 0; i < elProp.size(); i++) {
            if(elProp.get(i).getNome().equalsIgnoreCase(oldProp)){
                elProp.get(i).getAppIntestati().remove(this.codice);
            }
            if(elProp.get(i).getNome().equalsIgnoreCase(nuovoProp)){
                elProp.get(i).getAppIntestati().add(this.codice);
            }
        }
    }

    /**
     * trasforma il Vector di stringhe speseSostenute dell'oggetto Appartamento
     * in una stringa. da utilizzare quando si fà l'update del DB
     *
     *
     * @return listaSp un oggetto String contenente le spese
     */
public String vectorSpeseToString(){
    String listaSp = "";
    if (this.speseSostenute.size() > 0) {
        for (int i = 0; i < this.speseSostenute.size() - 1; i++) {
            listaSp = listaSp + this.speseSostenute.get(i) + " ";
        }
        listaSp = listaSp + this.speseSostenute.lastElement();
    }
    return (listaSp);

    }





//metodi di classe


   /**
      * routine per il calcolo della somma di tutte le superfici
      * degli appartamenti
      * @param elApp un Vector di oggetti Appartamento
      * @param conn un oggetto di tipo Connection
      * @return un double contenente la somma totale dei campi superficie
      *         degli oggetti Appartamento
      */
    public static double getSupTotale(Vector<Appartamento> elApp, Connection conn){
        double res=0;
        for (int i = 0; i < elApp.size(); i++) {
            res = res + elApp.get(i).getSuperficie();
        }
        return (res);
    }

/**
 * stampa a video le info relative aggli appartamenti presenti
 * @param vApp un Vector di oggetti Appartamento
 */
public static void getInfoAppartamenti(Vector<Appartamento> vApp){

    String info = "\nAPPARTAMENTI:\n";
    for (int i = 0; i < vApp.size(); i++) {

//        System.out.format("\ncodice: '%s'  proprietario: '%s'  inquil: '%s'   numvani: '%s' superficie: '%f'",vApp.get(i).getCodice(),
//                            vApp.get(i).getProprietario(),vApp.get(i).getInquilino(),vApp.get(i).getNumvani(), vApp.get(i).getSuperficie());

        info = info+String.format("\ncodice app.to: %s  proprietario: %s  inquilino: %s   locali: %s   superficie: %.2f mq",vApp.get(i).getCodice(),
                            vApp.get(i).getProprietario(),vApp.get(i).getInquilino(),vApp.get(i).getNumvani(), vApp.get(i).getSuperficie());


//        System.out.println(String.format(vApp.get(i).getCodice()+"\t\t\t"+vApp.get(i).getProprietario()
//                            +"\t\t"+vApp.get(i).getInquilino()+"\t\t\t"+vApp.get(i).getNumvani()
//                            +"\t"+vApp.get(i).getSuperficie()));

    }
    System.out.println(info);
}

    //interrogazione e update DB

/**
 *effettua la lettura della tabella APPARTAMENTI. ogni record (e i relativi campi)
 * è inserito in oggetto Appartamento, a sua volta inserito in un Vector di
 * oggetti Appartamento
 * @param conn un oggetto Connection conn
 * @return elApp un Vector di oggetti Appartamento
 * @throws SQLException
 */
    public static Vector<Appartamento> readDB(Connection conn) throws SQLException {
        Vector<Appartamento> elApp = new Vector<Appartamento>();
        Statement st;
        ResultSet rs;
        st = conn.createStatement();
        rs = st.executeQuery("select * from condominio.appartamenti");
        while (rs.next()) {
            Appartamento tmp = new Appartamento();
            Vector<String> vSpSost = new Vector<String>();
            tmp.setCodice(rs.getString("id"));
            tmp.setNumvani(rs.getInt("numvani"));
            tmp.setInquilino(rs.getString("inquilino"));
            tmp.setProprietario(rs.getString("proprietario"));
            tmp.setSuperficie(rs.getDouble("superficie"));
            if (!rs.getString("spesesostenute").isEmpty()) {
                String[] listaS = rs.getString("spesesostenute").split(" ");
                for (int i = 0; i < listaS.length; i++) {
                    vSpSost.add(listaS[i]);
                }
                tmp.setSpeseSostenute(vSpSost);
            }
            elApp.add(tmp);
        }
        st.close();
        rs.close();
        return (elApp);
    }



    /**
     * metodo static per l'update del DB della corripondente tabella APPARTAMENTI
     * @param elApp un Vector elApp di oggetti Appartamento
     * @param conn un oggetto Connection conn
     * @throws SQLException
     */
    public static void updateDB(Vector<Appartamento> elApp, Connection conn) throws SQLException {

        boolean chk = true;
        for (int i = 0; i < elApp.size(); i++) {
            if (chk) {
                Statement st = conn.createStatement();
                Appartamento tmp_app = elApp.get(i);
                String tmp_listasp = tmp_app.vectorSpeseToString();

                st.addBatch("update condominio.appartamenti set proprietario='" + tmp_app.getProprietario() + "' where id='" + tmp_app.getCodice() + "'");
                st.addBatch("update condominio.appartamenti set spesesostenute='" + tmp_listasp + "' where id='" + tmp_app.getCodice() + "'");
                int[] res = st.executeBatch();
                for (int j = 0; j < res.length; j++) {
                    if (res[j] < 0) {
                        chk = false;
                    }
                }
                if (!chk) {
                    System.out.println("errori nell'update della tabella appartamenti");
                }
                st.close();
            }

        }
        if (chk) {
            System.out.println("update della tabella APPARTAMENTI effettuato con successo");

        }


    }
}
//controllato
