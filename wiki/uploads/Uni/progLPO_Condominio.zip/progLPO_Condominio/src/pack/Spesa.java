/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package pack;

import java.sql.*;
import java.util.Vector;

/**
 * Spesa - Classe contenenti i dati relativi a una spesa
 * 
 */
public class Spesa {

    // variabili di classe
    private String codice;
    private String tipo;
    private String data;
    private double importo;

    //costruttore
    public Spesa() {
    }




//metodi di istanza



    /**
     * restituisce il codice della spesa
     * @return codice
     */
    public String getCodice() {
        return codice;
    }

    /**
     * inserisce il codice della spesa
     * @param codice
     */
    public void setCodice(String codice) {
        this.codice = codice;
    }

    /**
     * restituisce la data della spesa
     * @return data
     */
    public String getData() {
        return data;
    }

    /**
     * inserisce la data della spesa
     * @param data
     */
    public void setData(String data) {
        this.data = data;
    }

    /**
     * restituisce l'importo della spesa
     * @return importo
     */
    public double getImporto() {
        return importo;
    }

    /**
     *inserisce l'importo della spesa
     * @param importo
     */
    public void setImporto(double importo) {
        this.importo = importo;
    }

    /**
     * restituisce la tipologia della spesa
     * @return tipo
     */
    public String getTipo() {
        return tipo;
    }

    /**
     * inserisce la tipologia della spesa
     * @param tipo
     */
    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    /**
     * divide l'importo di un oggetto Spesa tra i diversi proprietari e lo divide
     * proporzionalmente alla loro quota di superfice totale occupata. successivamente
     * addebita l'importo sul saldo di ognuno di essi
     * @param elProp Vector di oggetti Proprietario
     * @param suptotale double contenente la superficie totale
     */
    public void dividiEaddebita(Vector<Proprietario> elProp, double  suptotale){
        for (int i = 0; i < elProp.size(); i++) {
            double impIndividuale = ((this.importo/100)*elProp.get(i).getQuotasup());
            elProp.get(i).setSaldo(elProp.get(i).getSaldo() - impIndividuale);
        }
    }


    /**
     * aggiunge il codice di una spesa ad ogni appartamento del condominio
     * @param elApp Vector di oggetti Appartamento
     */
    public void addToAppartamenti(Vector<Appartamento> elApp){
        for (int i = 0; i < elApp.size(); i++) {
            elApp.get(i).getSpeseSostenute().add(this.codice);
        }
    }

/**
 * visualizza l'importo addebitato a ciascun proprietario per questa spesa (non speciale)
 * @param vPropr un Vector di oggetti Proprietario
 */
    public void spesaPerProprietario(Vector<Proprietario> vPropr){
        for (int i = 0; i < vPropr.size(); i++) {
            System.out.print("\nnome proprietario: "+vPropr.get(i).getNome()
                             +"\t\tspesa relativa: "+Controlli.arrotonda(((this.importo/100)*vPropr.get(i).getQuotasup()),2)
                             );
        }
    }




//metodi di classe




    //interrogazione e update DB
    public static Vector<Spesa> readDB(Connection conn) throws SQLException{

        Statement st; ResultSet rs;
        Vector<Spesa> elSpese = new Vector<Spesa>();
        st = conn.createStatement();
        rs = st.executeQuery("select * from condominio.spese");
        while(rs.next()){
             Spesa tmp = new Spesa();
             tmp.setCodice(rs.getString("id"));
             tmp.setData(rs.getString("data"));
             tmp.setTipo(rs.getString("tipo"));
             tmp.setImporto(rs.getDouble("importo"));
             elSpese.add(tmp);
        }
        rs.close(); st.close();

        return (elSpese);

    }

    /**
     * esegue l'update della tabella SPESE su db
     * @param elSpese un Vector di oggetti Spesa
     * @param conn un oggetto Connection
     * @param posVecSpes un intero indicante la dimensione di elSpese prima
     * dell'inserimento della spesa
     * @throws SQLException
     */
    public static void updateDB(Vector<Spesa> elSpese, Connection conn, int posVecSpes) throws SQLException{
        Statement st;
        String qIns = "";
        st = conn.createStatement();
        for (int i = posVecSpes; i < elSpese.size(); i++) {
            qIns = "insert into condominio.spese values('"
                          +elSpese.get(i).getCodice()
                          +"','"
                          +Controlli.formatDate(elSpese.get(i).getData())
                          +"','"
                          +elSpese.get(i).getTipo()
                          +"',"
                          +elSpese.get(i).getImporto()
                          +")";

            st.addBatch(qIns);
            
        }
        boolean chk = true;
        int i = 0;
        int[] res = st.executeBatch();
        while(i<res.length && !chk){
            if(res[i]<0) chk=false;
            i++;
        }

        if(chk) System.out.println("update tabella SPESE avvenuto con successo");
        else
            System.out.println("problemi nell'update della tabella SPESE");

        st.close();
    }

}

//controllato
