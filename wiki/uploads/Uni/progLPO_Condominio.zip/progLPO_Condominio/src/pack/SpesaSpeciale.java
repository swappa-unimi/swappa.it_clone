/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pack;

import java.sql.*;
import java.util.Vector;

/**
 * SpesaSpeciale - Classe contenenti i dati relativi a una spesa speciale
 * 
 */
public class SpesaSpeciale extends Spesa {

    //variabili di classe
    private String codApp;

    //costruttore
    public SpesaSpeciale() {
    }
    /*
     * le altre varibili di classe e i relativi getter e setter vengono
     * ereditati dalla superclasse Spesa
     * */


//metodi di istanza



     /**
      * restituisce il codice dell'appartamento per il quale è stata effettuata
      * la spesa speciale
      * @return codApp
      */
    public String getCodApp() {
        return codApp;
    }

    /**
     * inserisce il codice dell'appartamento per il quale si effettua la spesa
     * speciale
     * @param codApp
     */
    public void setCodApp(String codApp) {
        this.codApp = codApp;
    }


    /**
     * addebita l'importo di una spesa speciale sul saldo del proprietario del
     * relativo appartamento
     * @param elProp un Vector di oggetti Proprietario
     * @param elApp un Vector di Oggetti Appartamento
     */
    public void inserisciSpesaSpeciale(Vector<Proprietario> elProp, Vector<Appartamento> elApp) {
        String nomeProp = "";
        for (int i = 0; i < elApp.size(); i++) {
            if (elApp.get(i).getCodice().equalsIgnoreCase(this.codApp)) {
                nomeProp = elApp.get(i).getProprietario();
                break;
            }
        }
        for (int i = 0; i < elProp.size(); i++) {
            if (elProp.get(i).getNome().equalsIgnoreCase(nomeProp)) {
                elProp.get(i).setSaldo(elProp.get(i).getSaldo() - this.getImporto());
                break;
            }
        }
        System.out.println("spesa speciale a carico di '"+nomeProp+"' inserita");
    }

    /**
     * inserisce il codice della spesa speciale nell'elenco delle spese del relativo
     * appartamento
     * @param elApp Vector di oggetti Appartamento
     */
    @Override
    public void addToAppartamenti(Vector<Appartamento> elApp) {
        for (int i = 0; i < elApp.size(); i++) {
            if (this.codApp.equalsIgnoreCase(elApp.get(i).getCodice())) {
                elApp.get(i).getSpeseSostenute().add(this.getCodice());
            }
        }
    }



//metodi statici



    /**
     * legge la tabella SPESESPECIALI da db. per ogni record è creato un oggetto
     * SpesaSpeciale e le sue variabili sono settate con i valori dei campi del
     * record. l'oggetto è poi inserito in un Vector di oggetti SpesaSpeciale
     * @param conn un oggetto di tipo Connection
     * @return un Vector di oggetti SpesaSpeciale
     * @throws SQLException
     */
    public static Vector<SpesaSpeciale> read_DB(Connection conn) throws SQLException {
        Vector<SpesaSpeciale> vSpSpec = new Vector<SpesaSpeciale>();
        Statement st;
        ResultSet rs;
        st = conn.createStatement();
        rs = st.executeQuery("select * from condominio.spesespeciali");
        while (rs.next()) {
            SpesaSpeciale tmp = new SpesaSpeciale();
            tmp.setCodice(rs.getString("id"));
            tmp.setData(rs.getString("data"));
            tmp.setImporto(rs.getDouble("importo"));
            tmp.setTipo(rs.getString("tipo"));
            tmp.setCodApp(rs.getString("app"));
            vSpSpec.add(tmp);
        }
        rs.close();
        st.close();
        return (vSpSpec);

    }



    /**
     * esegue l'inserimento di nuove spese nella tabella SPESESPECIALI del db.
     * @param vSpSpc un Vector di oggetti SpesaSpeciale
     * @param conn un oggetto Connection
     * @param posVecSpSpec un intero indicante la dimensione di vSpSpc prima
     * dell'inserimento della spesa
     * @throws SQLException
     */
    public static void update_DB(Vector<SpesaSpeciale> vSpSpc, Connection conn, int posVecSpSpec) throws SQLException {

        Statement st;
        st = conn.createStatement();
        String qIns="";
        for (int i = posVecSpSpec; i < vSpSpc.size(); i++) {
            qIns = "insert into condominio.spesespeciali values ('"
                  + vSpSpc.get(i).getCodice()
                  + "','"
                  + Controlli.formatDate(vSpSpc.get(i).getData())
                  + "','"
                  +vSpSpc.get(i).getTipo()
                  + "',"
                  + vSpSpc.get(i).getImporto()
                  + ",'"
                  + vSpSpc.get(i).getCodApp() + "')";

                  st.addBatch(qIns);
                  qIns="";
        }
        boolean check = true;
        int[] res = st.executeBatch();
        int i = 0;
        while (i < res.length && !check) {
            if (res[i] < 0) {
                check = false;
            }
            i++;
        }
        if (check) {
            System.out.println("update tabella SPESESPECIALI avvenuto con successo");
        } else {
            System.out.println("problemi nell'update della tabella SPESESPECIALI");
        }
        st.close();
    }

    //controllato


}







