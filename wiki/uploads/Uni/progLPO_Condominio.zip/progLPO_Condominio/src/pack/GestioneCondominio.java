
package pack;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Vector;

/**
 * Gestione Condominio - Gestisce la componente di interazione
 * con l'utente mediante interfaccia a riga di comando
 * 
 *
 *
 */
public class GestioneCondominio {

    /**
     * Main - menu principale con scelta opzioni
     * @param args the command line arguments
     */
    public static void main(String[] args) throws SQLException, IOException {

        Connection conn = Controlli.getDBconnection();
        Vector<Appartamento> vApp = Appartamento.readDB(conn);
        Vector<Proprietario> vProp = Proprietario.readDB(conn);
        int posVecProprietario = vProp.size();
        Vector<Spesa> vSpes = Spesa.readDB(conn);
        int posVecSpesa = vSpes.size();
        Vector<SpesaSpeciale> vSpSpc = SpesaSpeciale.read_DB(conn);
        int posVecSpSpec = vSpSpc.size();
        Vector<Pagamento> vPagam = Pagamento.readDB(conn);
        int posVecPagam = vPagam.size();
        final double supTotale = Appartamento.getSupTotale(vApp, conn);

        conn.close();


        BufferedReader kb_buf = new BufferedReader(new InputStreamReader(System.in));
        String inputTesto;
        System.out.println("\n\n----------|| GESTIONE CONDOMINIO ||----------");
        for (;;) {
            System.out.println("\nPremere:\n"
                           +"'1' per info relative agli appartamenti\n"
                           +"'2' per cambiare proprietario di un appartamento\n"
                           +"'3' per inserire una nuova spesa\n"
                           +"'4' per inserire un nuovo pagamento\n"
                           +"'5' per visualizzare il bilancio attuale\n"
                           +"'6' per visualizzare i proprietari in debito\n"
                           +"'7' per visualizzare le spese sostenute da un appartamento\n"
                           +"'8' per inserire una spesa speciale\n"
                           +"'e' per uscire\n"
                           +"---------------------------------------------");

            System.out.print("> ");

            inputTesto = kb_buf.readLine();


            if (inputTesto.equalsIgnoreCase("e")) {
                System.exit(0);
                break;
            }
            else if (inputTesto.equals("1")) {
                Appartamento.getInfoAppartamenti(vApp);
            }
            else if (inputTesto.equalsIgnoreCase("2")) {
                cambioProprietario(vApp, vProp, supTotale);
            }
            else if (inputTesto.equals("3")) {
                nuovaSpesa(vSpes, vApp, vProp, supTotale);
            }
            else if (inputTesto.equals("4")) {
                //inserimento nuovo pagamento
                nuovoPagamento(vPagam, vProp);
            }
            else if (inputTesto.equals("5")) {
                //visualizza bilancio
                visualizzaBilancio(vSpes, vPagam);
            }
            else if (inputTesto.equals("6")) {
                //visualizza debitori
                Proprietario.elencaDebitori(vProp);
            }
            else if (inputTesto.equals("7")) {
                //visualizza spese di un appartamento
                visualizzaSpeseApp(vApp, vSpes, vSpSpc);
            }
            else if (inputTesto.equals("8")){
               //inserisci spesa speciale
                nuovaSpesaSpeciale(vSpSpc, vApp, vProp);
            }
            else if (inputTesto.equals("9")) {
                //interrompi e passa a routine di scrittura su DB
                break;
            }
            else {
            }
        }

        conn = Controlli.getDBconnection();
        Appartamento.updateDB(vApp, conn);
        Proprietario.updateDB(vProp, conn, posVecProprietario);
        Spesa.updateDB(vSpes, conn, posVecSpesa);
        SpesaSpeciale.update_DB(vSpSpc, conn, posVecSpSpec);
        Pagamento.updateDB(vPagam, conn, posVecPagam);

        conn.close();
        kb_buf.close();
        System.exit(0);

        }

    //routines da utilizzare nel main

    /**
     * routine per il cambio del proprietario. da utilizzare nel main
     * @param vApp Vector di oggetti Appartamento
     * @param vProp Vector di oggetti Proprietario
     * @param supTotale double conetente la somma delle sup. di tutti gli
     * appartamenti
     */
    public static void cambioProprietario(Vector<Appartamento> vApp, Vector<Proprietario> vProp, double supTotale) throws IOException{

        BufferedReader buffTastiera = new BufferedReader(new InputStreamReader(System.in));
        String newName = null;
        String app = null;

        System.out.println("**CAMBIO PROPRIETARIO**");
        System.out.println("Appartamenti:\n");
        for (int i = 0; i < vApp.size(); i++) {
            System.out.println("codice: " + vApp.get(i).getCodice() + "\t proprietario: " + vApp.get(i).getProprietario());
        }
        System.out.println("\nSi desidera cambiare proprietario di un appartamento(S per confermare)?\n");

        try {
            newName = buffTastiera.readLine();
        } catch (IOException ex) {
            System.out.println("errore nell'immisione nuovo nome. eccezione: " + ex);
        }
        if (newName.equalsIgnoreCase("S")) {
            System.out.println("indicare codice appartamento:\n");
            try {
                app = buffTastiera.readLine();
            } catch (IOException ex) {
                System.out.println("errore nell'inserimento dati. eccezione: "+ex);
            }
            System.out.println("Inserire nome proprietario:\n");
            newName = buffTastiera.readLine();

            //inserimento di un eventuale nuovo proprietario nel Vector vProp
            boolean chk_name=false;
            for (int i = 0; i < vProp.size(); i++) {
                if(newName.equalsIgnoreCase(vProp.get(i).getNome())){
                    chk_name = true;
                }
            }
            if (!chk_name) {
                System.out.println("\nProprietario non esistente fra quelli già presenti.\nInserire ulteriori dati\nIndirizzo:\n");
                Proprietario nuovoP = new Proprietario();
                nuovoP.setNome(newName);
                String address = buffTastiera.readLine();
                nuovoP.setIndirizzo(address);
                System.out.println("Telefono:\n");
                String telephone = buffTastiera.readLine();
                nuovoP.setTelefono(telephone);
                Vector<String> appIn = new Vector<String>();
                appIn.add(app);
                nuovoP.setAppIntestati(appIn);
                vProp.add(nuovoP);
                for (int i = 0; i < vApp.size(); i++) {
                    if (vApp.get(i).getCodice().equalsIgnoreCase(app)) {
                        vApp.get(i).setProprietario(nuovoP.getNome());
                    }
                }
            } else {
                for (int i = 0; i < vApp.size(); i++) {
                    if (vApp.get(i).getCodice().equalsIgnoreCase(app)) {
                        vApp.get(i).cambiaProprietario(newName, vProp);
                    }
                }
            }

            //calcolo quota % superficie
            for (int j = 0; j < vProp.size(); j++) {
                vProp.get(j).calcolaQuotaSup(supTotale, vApp);
            }
//            try {
//                buffTastiera.close();
//            } catch (IOException ex) {
//               System.out.println("errore nella chiusura del buffer. eccezione:"+ex);
//            }
            System.out.println("\n\nFatto. premere 9 per scrivere le modifiche su DB e uscire");

    }
}

    /**
     * routine per l'inserimento di una spesa. da utilizzare nel main
     * @param vSpes un Vector di oggetti Spesa
     * @param vApp un Vector di oggetti Appartamento
     * @param vProp un Vectro di oggetti Proprietario
     * @param supTotale un double contenente la somma delle sup. di tutti gli
     * appartmanenti
     */
    public static void nuovaSpesa(Vector<Spesa> vSpes, Vector<Appartamento> vApp, Vector<Proprietario> vProp, double supTotale) throws IOException{

        BufferedReader buffTastiera = new BufferedReader(new InputStreamReader(System.in));

            //inserimento spesa
            System.out.println("\n**NUOVA SPESA**");
            System.out.println("inserire tipologia spesa:\n");
            String newSpesa = null;
        try {
            newSpesa = buffTastiera.readLine();
        } catch (IOException ex) {
            System.out.println("errore nell'immissione dati. eccezione:"+ex);
        }

            System.out.println("inserire importo (euro.centesimi):\n");
            double impNewSpesa = 0;
        try {
            impNewSpesa = Double.parseDouble(buffTastiera.readLine());
        } catch (IOException ex) {
            System.out.println("errore nell'immisiione dati. eccezione:"+ex);
        }
            boolean stop = false;
            String dataNewSpesa = null;
            while(!stop){
                System.out.println("inserire la data della spesa (GG/MM/AAAA):\n");
            try {
                dataNewSpesa = buffTastiera.readLine();
            } catch (IOException ex) {
                System.out.println("errore nell'immissione dati. eccezione:"+ex);
            }
                  if(Controlli.checkDate(dataNewSpesa)){
                      stop=true;
                  }
            }

            Spesa newObjSpesa = new Spesa();
            String codNewSpesa;
            if(vSpes.isEmpty())codNewSpesa = "s1";
            else
            codNewSpesa = "s"+(vSpes.size()+1);
            newObjSpesa.setCodice(codNewSpesa);
            newObjSpesa.setData(dataNewSpesa);
            newObjSpesa.setImporto(Controlli.arrotonda(impNewSpesa,2));
            newObjSpesa.setTipo(newSpesa);
            newObjSpesa.addToAppartamenti(vApp);
            newObjSpesa.dividiEaddebita(vProp, supTotale);
            vSpes.add(newObjSpesa);
            System.out.println("visualizzare l'importo relativo per ogni proprietario per la spesa '"+newSpesa+"'?\n"
                                +"premere S se ok");
            if(buffTastiera.readLine().equalsIgnoreCase("S")){
                newObjSpesa.spesaPerProprietario(vProp);
            }
            System.out.println("\n\nFatto. premere 9 per scrivere le modifiche su DB e uscire");

    }

    /**
     * routine per l'inserimento di un nuovo pagamento da parte di un proprietario
     * da utilizzare nel main
     * @param vPag Vector di oggetti Pagamento
     * @param vProp Vector di oggetti Proprietario
     * @throws IOException
    */
    public static void nuovoPagamento(Vector<Pagamento> vPag, Vector<Proprietario> vProp) throws IOException{
        BufferedReader kb_buff = new BufferedReader(new InputStreamReader(System.in));
        String txtbuff = "";
        boolean stop = false;
        Pagamento newPag = new Pagamento();
        System.out.println("**NUOVO PAGAMENTO**");
        while(!stop){
            System.out.println("inserire importo (euro.cent):\n");
            txtbuff = kb_buff.readLine();
            try{
            double d = Double.parseDouble(txtbuff);
            newPag.setImporto(d);
            stop = true;
            }
            catch(NumberFormatException e){
                System.out.println("inserire correttamente il valore!");
            }
        }
        System.out.println("inserire nominativo proprietario che effettua il pagamento(numero corrispondente):\n");
        int tmp=0;
        int i=0;
        stop = false;
        while (!stop) {
            for (i = 0; i < vProp.size(); i++) {
                System.out.println(i + ") " + vProp.get(i).getNome());
            }
            txtbuff = kb_buff.readLine();
            try {
                tmp = Integer.parseInt(txtbuff);
                stop = true;
            } catch (NumberFormatException e) {
                System.out.println("digitare correttamente il numero corrispondente");
            }
        }
        for (int j = 0; j < vProp.size(); j++) {
            if(j==tmp){
                newPag.setNominativo(vProp.get(j).getNome());
            }
        }
        stop = false;
        while(!stop){
            System.out.println("inserire data(GG/MM/AAAA):\n");
            txtbuff = kb_buff.readLine();
            if(Controlli.checkDate(txtbuff)){
                newPag.setData(txtbuff);
                stop=true;
            }
            else
                System.out.println("inserire correttamente la data!");
        }
        newPag.setCodice("p"+(vPag.size()+1));
        vPag.add(newPag);

        newPag.effettuaPagamento(vProp);
        System.out.println("Fatto. premere 9 per scrivere le modifiche su DB e uscire");
//        kb_buff.close();

    }

    /**
     * routine per visualizzare il bilancio del condominio (somma pagamenti - somma spese)
     * da utilizzare nel main
     * @param vSpes un Vector di oggetti Spesa
     * @param vPag un Vector di oggetti Pagamento
     *
     */
    public static void visualizzaBilancio(Vector<Spesa> vSpes, Vector<Pagamento> vPag) {

        double totSpese, totPagam;
        totPagam = totSpese = 0;
        for (int i = 0; i < vSpes.size(); i++) {
            totSpese = totSpese + vSpes.get(i).getImporto();
        }
        for (int i = 0; i < vPag.size(); i++) {
            totPagam = totPagam + vPag.get(i).getImporto();
        }

        double bilancio = Controlli.arrotonda((totPagam - totSpese), 2);
        if (bilancio < 0) {
            System.out.println("BILANCIO IN ROSSO:");
            System.out.println(bilancio + " euro");
        } else {
            System.out.println("BILANCIO: " + bilancio+" euro");
        }
    }

    /**
     * routine per la visualizzazione delle spese di un determinato
     * appartamento. da utilizzare nel main
     * @param vApp un Vector di oggetti Appartamento
     * @param vSpes un Vector di oggetti Spesa
     * @throws IOException
     */
    public static void visualizzaSpeseApp(Vector<Appartamento> vApp, Vector<Spesa> vSpes, Vector<SpesaSpeciale> vSpSpec) throws IOException {
        BufferedReader kb_buff = new BufferedReader(new InputStreamReader(System.in));
        String txtbuff, id_app = "";
        boolean stop = false;
        System.out.println("**VISUALIZZA SPESE APPARTAMENTO**");
        for (int i = 0; i < vApp.size(); i++) {
            System.out.println("codice: " + vApp.get(i).getCodice() + "\t" + vApp.get(i).getProprietario());
        }
        while (!stop) {
            System.out.println("inserire codice appartamento del quale si vogliono visualizzare le spese:\n");
            txtbuff = kb_buff.readLine();
            int test = 0;
            try{
                test = Integer.parseInt(txtbuff.substring(1));
            }
            catch(NumberFormatException e){
                System.out.println("immettere correttamente il codice!");
            }
            if ((txtbuff.startsWith("a") && (test <= vApp.size()))) {
                id_app = txtbuff;
                stop = true;
            } else {
                System.out.println("immettere correttamente il codice appartamento!");
            }
        }
                for (int i = 0; i < vApp.size(); i++) {
            if (vApp.get(i).getCodice().equalsIgnoreCase(id_app)) {
                vApp.get(i).elencaSpese(vSpes,vSpSpec);
                break;
            }
        }

    }

    /**
     * routine per l'inserimento di una nuova spesa speciale per un certo appartemento, che
     * verrà addebitata al relativo proprietario. da utilizzare nel main
     * @param vSpesaSpeciale un Vector di oggetti SpesaSpeciale
     * @param vAppart un Vector di oggetti Appartamento
     * @param vPropr un Vector di oggetti Proprietario
     * @throws IOException
     */
    public static void nuovaSpesaSpeciale(Vector<SpesaSpeciale> vSpesaSpeciale, Vector<Appartamento> vAppart, Vector<Proprietario> vPropr) throws IOException {
        BufferedReader buffTastiera = new BufferedReader(new InputStreamReader(System.in));
        String txtbuff = "";
        String codapp = "";
        String nomeprop= "";
        double importo=0;

        SpesaSpeciale spspec = new SpesaSpeciale();
        boolean stop = false;
        System.out.println("\n\n**NUOVA SPESA SPECIALE**\n");
        for (int i = 0; i < vAppart.size(); i++) {
            System.out.println("codice appartamento: " + vAppart.get(i).getCodice() + "\tinquilino: " + vAppart.get(i).getInquilino() + "\tproprietario: " + vAppart.get(i).getProprietario());
        }
        System.out.println("\ninserire codice appartmento:\n");

        while (!stop) {
            int test = 0;
            txtbuff = buffTastiera.readLine();
            try {
                test = Integer.parseInt(txtbuff.substring(1));
            } catch (NumberFormatException e) {
                System.out.println("inserire correttamente il codice!");
            }
            if (txtbuff.startsWith("a") && (test <= vAppart.size())) {
                spspec.setCodApp(txtbuff);
                stop=true;
            }
            else{
                System.out.println("inserire correttamente il codice!");
            }

        }
        String codSS = "ss"+(vSpesaSpeciale.size()+1);
        spspec.setCodice(codSS);
        for (int i = 0; i < vAppart.size(); i++) {
              if(vAppart.get(i).getCodice().equalsIgnoreCase(spspec.getCodApp())){
                  spspec.setCodice(codSS);
                  break;
              }
        }
        System.out.println("inserire descrizione spesa");
        spspec.setTipo(buffTastiera.readLine());
        System.out.println("inserire importo (euro.centesimi):\n");
        txtbuff=buffTastiera.readLine();
        stop=false;
        while (!stop) {
            try {
                spspec.setImporto(Controlli.arrotonda(Double.parseDouble(txtbuff),2));
                stop = true;
            } catch (NumberFormatException e) {
                System.out.println("inserire correttamente l'importo");
            }
        }
        System.out.println("inserire data (GG/MM/AAAA):\n");
        txtbuff=buffTastiera.readLine();
        stop=false;
        while(!stop){
            if(Controlli.checkDate(txtbuff)){
                spspec.setData(txtbuff);
                stop=true;
            }
        }
        vSpesaSpeciale.add(spspec);
        spspec.inserisciSpesaSpeciale(vPropr, vAppart);
        spspec.addToAppartamenti(vAppart);
        System.out.println("\n\nFatto. premere 9 per scrivere le modifiche su DB e uscire");
    }


}
