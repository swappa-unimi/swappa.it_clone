/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package pack;

import java.sql.*;
import java.util.Vector;

/**
 * Proprietario - Classe contenenti i dati relativi a un proprietario
 */
public class Proprietario {

    //variabili di classe
    private String nome;
    private String indirizzo;
    private String telefono;
    private double saldo;
    private double quotasup;
    private Vector<String> appIntestati;

    //costruttore
    public Proprietario() {
    }

//metodi di istanza

    /**
     * restituisce gli appartamenti intestati a questo proprietario
     * @return appIntestati
     */
    public Vector<String> getAppIntestati() {
        return appIntestati;
    }

    /**
     * inserisce gli appartamenti intetstati a questo proprietario
     * @param appIntestati
     */
    public void setAppIntestati(Vector<String> appIntestati) {
        this.appIntestati = appIntestati;
    }

    /**
     * restituisce l'indirizzo di questo proprietario
     * @return indirizzo
     */
    public String getIndirizzo() {
        return indirizzo;
    }

    /**
     * inserisce l'indirizzo per questo proprietario
     * @param indirizzo
     */
    public void setIndirizzo(String indirizzo) {
        this.indirizzo = indirizzo;
    }

    /**
     * restituisce il nome di questo proprietario
     * @return nome
     */
    public String getNome() {
        return nome;
    }

    /**
     * inserisce il nome del proprietario
     * @param nome
     */
    public void setNome(String nome) {
        this.nome = nome;
    }

    /**
     * restituisce il saldo del proprietario
     * @return saldo
     */
    public double getSaldo() {
        return saldo;
    }

    /**
     * restituisce la quota di superficie (percentuale) di questo proprietario
     * rispetto alla superficie totale di tutti appartamenti
     * @return quotasup
     */
    public double getQuotasup() {
        return quotasup;
    }

    /**
     * inserisce la quota di superficie (percentuale) di questo proprietario
     * rispetto alla superficie totale di tutti appartamenti
     * @param quotasup
     */
    public void setQuotasup(double quotasup) {
        this.quotasup = quotasup;
    }

    /**
     * inserisce il saldo del proprietario
     * @param saldo
     */
    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }

    /**
     * restituisce il numero telefonico del proprietario
     * @return telefono
     */
    public String getTelefono() {
        return telefono;
    }

    /**
     * inserisce il numero di telefono del proprietario
     * @param telefono
     */
    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    /**
     * restituisce la superficie totale (mq) posseduta dal proprietario
     * @param suptotale la somma di tutte le superfici di tutti gli appartamenti
     * @return la superficie totale del proprietario
     */
    public double supPossedutaTotale(double suptotale){
        return((suptotale/100)*this.quotasup);
    }

    /**
     * calcola la quota superficie (in %) che possiede questo proprietario
     * in relazione alla superficie totale.
     * @param suptot la superfice totale degli appartamenti
     * @param vApp un Vector di oggetti Appartamento
     */
    public void calcolaQuotaSup(double suptot, Vector<Appartamento> vApp){
        double supTotPropr = 0;
        for (int i = 0; i < vApp.size(); i++) {
            if(this.nome.equalsIgnoreCase(vApp.get(i).getProprietario())){
                supTotPropr = supTotPropr + vApp.get(i).getSuperficie();
            }
        }
        double tmp = (supTotPropr/suptot)*100;
        this.quotasup = Controlli.arrotonda(tmp, 2);
    }

        /**
     * trasforma il Vector di stringhe appIntestati dell'oggetto Proprietario
     * in una stringa. da utilizzare quando si fà l'update del DB
     * @return listaApp una stringa contenente la lista degli appartamenti intestati
     *          a questo proprietario
     */
    public String vectorAppIntToString(){
        String listaApp = "";
        for (int i = 0; i < (this.appIntestati.size()); i++) {
             listaApp = listaApp+this.appIntestati.get(i)+" ";
        }
//        listaApp = listaApp+this.appIntestati.lastElement();
        return (listaApp);

    }







//metodi di classe
    /**
     * visualizza info relative ai proprietari con saldo in negativo (campo
     * Saldo minore di 0)
     * @param elProp un Vector di oggetti Proprietario
     */
    public static void elencaDebitori(Vector<Proprietario> elProp){
        int n=0;
        System.out.println("Elenco proprietari in debito:");
        for (int i = 0; i < elProp.size(); i++) {
             if(elProp.get(i).getSaldo()<0){
                 System.out.println("nome: "+elProp.get(i).getNome()+"\tindirizzo: "
                         +elProp.get(i).getIndirizzo()+"\ndebito: "
                         +Math.abs(elProp.get(i).getSaldo()));
                         n++;
             }

        }
        if(n==0)System.out.println("Non risultano proprietari in debito");
    }



    //interrogazione e update DB

    /**
     * effettua la lettura della tabella PROPRIETARI. ogni record (e i relativi campi)
     * è inserito in oggetto Proprietario, a sua volta inserito in un Vector di
     * oggetti Proprietario
     * @param conn
     * @return elProp un Vector di oggetti Proprietario
     * @throws SQLException
     */
    public static Vector<Proprietario> readDB(Connection conn) throws SQLException{
        Vector<Proprietario> elProp = new Vector<Proprietario>();
        Statement st; ResultSet rs;
        st = conn.createStatement();
        rs = st.executeQuery("select * from condominio.proprietari");
        while(rs.next()){
            Proprietario tmp = new Proprietario();
            Vector<String> vApIn = new Vector<String>();
            tmp.setNome(rs.getString("nome"));
            tmp.setIndirizzo(rs.getString("indirizzo"));
            tmp.setTelefono(rs.getString("telefono"));
            tmp.setSaldo(rs.getDouble("saldo"));
            tmp.setQuotasup(rs.getDouble("quotasup"));
            String[]tmp_ai = rs.getString("appintestati").split(" ");
            for (int i = 0; i < tmp_ai.length; i++) {
                vApIn.add(tmp_ai[i]);
            }
            tmp.setAppIntestati(vApIn);
            elProp.add(tmp);
        }

        return (elProp);

    }


    /**
     * routine per l'update su DB della corrispondente tabella PROPRIETARI.
     * Riceve in input
     * @param elProp un Vector di oggetti Proprietario
     * @param conn un oggetto Connection
     * @throws SQLException
     */
    public static void updateDB(Vector<Proprietario> elProp, Connection conn, int posVecProp) throws SQLException{
        Statement st = null;
        boolean chk = true;
        if(elProp.size()>posVecProp){
            boolean check = true;
            String qIns = "";
            st = conn.createStatement();
            for (int i = posVecProp; i < elProp.size(); i++) {

                qIns = "insert into condominio.proprietari values ('"
                        +elProp.get(i).getNome()+"','"
                        +elProp.get(i).getIndirizzo()+"',0,0,' ','"
                        +elProp.get(i).getTelefono()+"')";
                st.addBatch(qIns);
            }
            int[] res = st.executeBatch();
            for (int i = 0; i < res.length; i++) {
                if(res[i]<0) check = false;
            }
            if(!check)System.out.println("errori nell'inserimento in DB del nuovo proprietario");
        }
        for (int i = 0; i < elProp.size(); i++) {
            if (chk) {
                st = conn.createStatement();
                Proprietario tmp_prop= elProp.get(i);
                String tmp_listasp = tmp_prop.vectorAppIntToString();
                String updNome = "update condominio.proprietari set saldo="
                            + tmp_prop.getSaldo()
                            + " where nome='"
                            + tmp_prop.getNome() + "'";
                st.addBatch(updNome);
                String updCodApp = "update condominio.proprietari set appintestati='"
                            + tmp_listasp
                            + "' where nome='" + tmp_prop.getNome()
                            + "'";
                st.addBatch(updCodApp);
                String updProp = "update condominio.proprietari set quotasup="
                            + tmp_prop.getQuotasup()
                            + " where nome='" + tmp_prop.getNome()
                            + "'";
                st.addBatch(updProp);
                int[] res = st.executeBatch();
                for (int j = 0; j < res.length; j++) {
                    if (res[j] < 0) {
                        chk = false;
                    }
                }
                if(!chk)System.out.println("errori nell'update della tabella PROPRIETARI");
            }
        }
        if(chk)System.out.println("update della tabella PROPRIETARI effettuato con successo");
        st.close();
    }

//controllato








}

