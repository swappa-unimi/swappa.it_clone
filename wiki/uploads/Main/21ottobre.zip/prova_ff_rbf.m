load prof1;

p = X';
t = Y';

[p2,ps] = mapminmax(p, 0, 1);
[t2,ts] = mapminmax(t, 0, 1);

[trainV,val,test] = dividevec(p2,t2,0.20,0.20);

net = newff(minmax(p2),[30 1], {'radbas', 'purelin'}, 'trainlm');
net.trainParam.epochs = 20000;

[net,tr]=train(net,trainV.P,trainV.T,[],[],val,test);

a2 = sim(net,p2);
a = mapminmax('reverse',a2,ts);
[m,b,r] = postreg(a,t);

figure;
axis equal;
hold on
plot(p,t, '.', 'MarkerSize', 5);
plot(p,a,'r-', 'LineWidth', 2);