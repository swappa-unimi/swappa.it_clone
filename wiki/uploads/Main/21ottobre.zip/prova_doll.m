load doll.txt;
X = doll(:,1);
Y = doll(:,2);
Z = doll(:,3);

p = [X'; Y'];
t = Z';

%%mapminmax prende un insieme di dati (p) e li rimappa sull'intervallo dato,
%%in questo caso che va da 0 a 1. Questa procedura � utile per normalizzare
%%gli input. Particolarmente utile nelle rbf quando i dati di input sono
%%unidimensionali e le grandezze non sono tra loro confrontabili. La
%%risposta di mapminmax sono i nuovi valori rimappati e le informazioni
%%necessarie per eventualmente invertirlo
%%si rimappa sia sugli ingressi..
%   [p2,ps] = mapminmax(p, 0, 1);
%%..che sulle uscite (particolarmente necessario in questo caso perch�
%%tansig non riponde valori tra 0 e 1 (d� valori tra -1 e 1)
%   [t2,ts] = mapminmax(t, 0, 1);

%dividevec prende in ingresso un dataset (p2,t2) (ingresso e uscita), poi 
%le percentuali di dataset che andranno a costituire il dataset di 
%validazione e quello di testing. Quello che rimane sono i dati utilizzati
%per il train
%[trainV,val,test] = dividevec(p2,t2,0.20,0.20);

%NEWFF crea una nuova rete feed forward e mette il risultato in net
%argomenti:
%1� stabilisce l'intervallo di funzionamento della rete, in cui cadranno 
%   gli input. "minmax(p2)" equivale a dire "[min(p2) max(p2)]". Serve 
%   quindi per l'inizializzazione dei parametri interni. Ora per� basta
%   scrivere p e t, e se la vede lui per il ripartimento
%2� dice che ci sono due strati, uno di venti unit� e l'altra di 1
%3� identificano il tipo di neurone degli strati indicati precedentemente.
%   Tansig � un tipo di funzione di attivazione del neurone
%net = newff(minmax(p2),[20 1], {'tansig', 'tansig'});

%1--- utilizzo l'algoritmo di training di default
net = newff(p,t,[40 1], {'tansig', 'tansig'});

%2--- in questo modo potrei forzare ad utilizzare un algoritmo di training
%di backpropagation
%net = newff(p,t,[400 1], {'tansig', 'tansig'}, 'traingd');

%net = newff(minmax(p2),[40 1], {'logsig', 'logsig'}, 'trainlm');

%net non � solo una matrice, ma � una struttura
%in particolare uno dei campi di net.trainParam � epochs che tiene conto
%del numero di iterazioni che vengono fatte sulla rete net durante
%l'addestramento
net.trainParam.epochs = 50;

%TRAIN restituisce la rete addestrata
%argomenti:
%1� la rete
%2� il valore di ingresso per l'addestramento
%3� il valore di uscita per l'addestramento
%6� i dati che saranno utilizzati per l'addestramento (per stimare quanto
%   l'addestramento sta procedendo nella direzione che si vuole)
%7� per stimare alla fine dell'addestramento quanto bene la rete � riuscita
%   ad approssimare i dati in ingresso
%[net,tr]=train(net,trainV.P,trainV.T,[],[],val,test);
[net,tr]=train(net,p,t);

%SIM fa la simulazione della rete a partire dalla rete e dai dati di input
%passiamo la rete gi� inizializzata ed i valori di ingresso con i quali
%vogliamo calcolare l'uscita della rete. a2 contiene la risposta della rete
%a2 = sim(net,p2);
a = sim(net,p);
%applichiamo ad a2 la trasformazione inversa che avevamo applicato ai dati
%di ingresso della rete, cos� da ottenere un nuovo vettore a, che pu�
%essere cos� confrontato con la parte dei dati che rappresentavano le
%uscite desiderate
%a = mapminmax('reverse',a2,ts);
%postreg d� una stima della rete di regressione tra i dati di uscita
%ottenuti e quelli desiderati. Sostanzialmente ci dice quanto � stata brava
%la rete a stimare le uscite
[m,b,r] = postreg(a,t);

%quindi newff, train e sim sono i tre comandi fondamentali della toolbox

%1--- disegniamo come un insieme di punti
%figure;
%axis equal;
%hold on
%plot3(p(1,:),p(2,:),t, '.', 'MarkerSize', 1);
%plot3(p(1,:),p(2,:),a, 'r.', 'MarkerSize', 1);

%2--- disegniamo una superficie
figure;
axis equal;
hold on
plot3(p(1,:),p(2,:),t, '.', 'MarkerSize', 1);
plot3(p(1,:),p(2,:),a, 'r.', 'MarkerSize', 1);

xs = min(X):max(X);
ys = min(Y):max(Y);
[mx my] = meshgrid(xs,ys);

a = sim(net,[reshape(mx,1,numel(mx)); reshape(my,1,numel(my));]);
ma = reshape(a, size(mx,1), size(mx,2));
surfl(mx,my,ma);
shading interp;
colormap pink;
rotate3d